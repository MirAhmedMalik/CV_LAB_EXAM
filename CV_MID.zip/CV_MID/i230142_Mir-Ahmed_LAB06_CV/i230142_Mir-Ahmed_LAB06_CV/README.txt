LAB 06 - COMPUTER VISION (8 tasks)
Each Task folder is complete: notebook + its images/videos + requirements.txt.

HOW TO RUN
1) pip install -r requirements.txt   (inside the task folder)
2) jupyter notebook   -> open the .ipynb -> Run All
Keep the images/ and video/ folders next to the notebook.

TASKS
1 Screen Detection (Hough Lines)      - your lab photo
2 Asset Tracking (SIFT)               - your monitor/keyboard/scene + extra box test
3 Wavelet Anomaly Detection           - data generated inside the notebook
4 Object Recognition in Video (SIFT)  - OpenCV box + generated test video
5 Panoramic Image (SIFT)              - 2 sets of overlapping photos
6 Lane Detection (Hough Lines)        - 6 road images + road video
7 Coins Detection (Hough Circles)     - coins photo + round objects photo
8 Smart Security System               - surveillance video with alarm zone
