# Hough Transform - Circle Detection
# Main flow:
# Image -> Grayscale -> Blur -> HoughCircles

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read: {IMAGE_PATH}")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Blur to reduce noise.
gray_blurred = cv2.GaussianBlur(
    gray,
    (9, 9),
    2
)

# Detect circles.
circles = cv2.HoughCircles(
    gray_blurred,
    cv2.HOUGH_GRADIENT,
    dp=1,
    minDist=20,
    param1=100,
    param2=30,
    minRadius=10,
    maxRadius=200
)

circle_image = image.copy()

if circles is not None:
    circles = np.round(circles[0]).astype(int)
    print("Number of circles detected:", len(circles))

    for x, y, radius in circles:
        # Draw circle.
        cv2.circle(
            circle_image,
            (x, y),
            radius,
            (0, 255, 0),
            2
        )

        # Draw center point.
        cv2.circle(
            circle_image,
            (x, y),
            2,
            (0, 0, 255),
            3
        )
else:
    print("No circles detected.")

plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(circle_image, cv2.COLOR_BGR2RGB))
plt.title("Hough Circle Detection")
plt.axis("off")

plt.tight_layout()
plt.savefig("hough_circles_result.png", dpi=150)
plt.show()
