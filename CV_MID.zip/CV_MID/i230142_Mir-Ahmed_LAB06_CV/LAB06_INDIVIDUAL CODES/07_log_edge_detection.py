# LoG - Laplacian of Gaussian
# Main idea:
# Grayscale -> Gaussian Blur -> Laplacian

import cv2
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(
    image, cv2.COLOR_BGR2GRAY
)

# Step 1: Gaussian blur reduces noise
blurred = cv2.GaussianBlur(
    gray,
    (5, 5),
    1.4
)

# Step 2: Laplacian calculates the second derivative
laplacian = cv2.Laplacian(
    blurred,
    cv2.CV_64F
)

# Use absolute values so the result can be displayed
laplacian_abs = cv2.convertScaleAbs(
    laplacian
)

# Convert original image for display
image_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

# Display results
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(2, 2, 2)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale")
plt.axis("off")

plt.subplot(2, 2, 3)
plt.imshow(blurred, cmap="gray")
plt.title("Gaussian Blurred")
plt.axis("off")

plt.subplot(2, 2, 4)
plt.imshow(laplacian_abs, cmap="gray")
plt.title("Laplacian of Gaussian (LoG)")
plt.axis("off")

plt.tight_layout()
plt.show()
