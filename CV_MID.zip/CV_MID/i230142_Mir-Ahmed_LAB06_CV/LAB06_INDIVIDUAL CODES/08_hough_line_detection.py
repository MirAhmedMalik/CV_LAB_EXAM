# Hough Transform - Line Detection
# Main flow:
# Image -> Grayscale -> Canny -> Hough Lines

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read: {IMAGE_PATH}")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Hough works well after edge detection.
edges = cv2.Canny(gray, 50, 150)

# Copy original image so we can draw detected lines.
line_image = image.copy()

# Probabilistic Hough Transform.
lines = cv2.HoughLinesP(
    edges,
    1,             # rho resolution (pixels)
    np.pi / 180,   # theta resolution (radians)
    threshold=80,  # minimum votes
    minLineLength=50,
    maxLineGap=10
)

if lines is not None:
    print("Number of lines detected:", len(lines))

    # Draw every detected line.
    for line in lines:
        x1, y1, x2, y2 = line[0]

        cv2.line(
            line_image,
            (x1, y1),
            (x2, y2),
            (0, 0, 255),
            2
        )
else:
    print("No lines detected.")

plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(line_image, cv2.COLOR_BGR2RGB))
plt.title("Hough Line Detection")
plt.axis("off")

plt.tight_layout()
plt.savefig("hough_lines_result.png", dpi=150)
plt.show()
