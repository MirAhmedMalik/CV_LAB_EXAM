# SIFT - Feature Extraction
#
# Main idea:
# Image -> Grayscale -> SIFT -> Keypoints + Descriptors

import cv2
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to RGB for Matplotlib
image_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

# Convert to grayscale
gray = cv2.cvtColor(
    image, cv2.COLOR_BGR2GRAY
)

# Create SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints and calculate descriptors
keypoints, descriptors = sift.detectAndCompute(
    gray,
    None  # no mask
)

# Draw SIFT keypoints
image_keypoints = cv2.drawKeypoints(
    image_rgb,
    keypoints,
    None,
    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS
)

# Print useful information
print("Number of keypoints:", len(keypoints))

if descriptors is not None:
    print("Descriptor shape:", descriptors.shape)
    print("Each SIFT descriptor has", descriptors.shape[1], "values.")
else:
    print("No descriptors found.")

# Display
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(image_keypoints)
plt.title("SIFT Keypoints")
plt.axis("off")

plt.tight_layout()
plt.show()
