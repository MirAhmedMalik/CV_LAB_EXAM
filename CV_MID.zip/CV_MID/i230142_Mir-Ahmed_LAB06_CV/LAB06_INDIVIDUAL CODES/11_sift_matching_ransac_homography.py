# SIFT Feature Matching + RANSAC + Homography
#
# Main idea:
# 1. Detect SIFT features in two images
# 2. Match their descriptors
# 3. Remove bad matches with ratio test
# 4. Use RANSAC to reject outliers
# 5. Estimate homography
#
# Put these two files in the same folder:
# image1.jpg
# image2.jpg

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE1_PATH = "image1.jpg"
IMAGE2_PATH = "image2.jpg"

# Read both images
img1 = cv2.imread(IMAGE1_PATH)
img2 = cv2.imread(IMAGE2_PATH)

if img1 is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE1_PATH}")

if img2 is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE2_PATH}")

# Convert to grayscale
gray1 = cv2.cvtColor(
    img1, cv2.COLOR_BGR2GRAY
)

gray2 = cv2.cvtColor(
    img2, cv2.COLOR_BGR2GRAY
)

# Create SIFT detector
sift = cv2.SIFT_create()

# Find keypoints and descriptors
kp1, des1 = sift.detectAndCompute(
    gray1, None
)

kp2, des2 = sift.detectAndCompute(
    gray2, None
)

print("Keypoints in image 1:", len(kp1))
print("Keypoints in image 2:", len(kp2))

if des1 is None or des2 is None:
    raise RuntimeError("Could not find SIFT descriptors.")

# Brute-Force matcher
# SIFT descriptors use L2 distance.
bf = cv2.BFMatcher(cv2.NORM_L2)

# Find the 2 nearest matches for every descriptor
matches = bf.knnMatch(
    des1,
    des2,
    k=2
)

# Lowe ratio test
good_matches = []

for m, n in matches:
    if m.distance < 0.75 * n.distance:
        good_matches.append(m)

print("Good matches:", len(good_matches))

# At least 4 point pairs are needed for homography
if len(good_matches) < 4:
    raise RuntimeError(
        "Not enough good matches for homography."
    )

# Get matching point coordinates
src_pts = np.float32([
    kp1[m.queryIdx].pt
    for m in good_matches
]).reshape(-1, 1, 2)

dst_pts = np.float32([
    kp2[m.trainIdx].pt
    for m in good_matches
]).reshape(-1, 1, 2)

# Find homography using RANSAC
H, mask = cv2.findHomography(
    src_pts,
    dst_pts,
    cv2.RANSAC,
    5.0  # RANSAC reprojection threshold
)

if H is None or mask is None:
    raise RuntimeError(
        "Homography could not be estimated."
    )

# 1 = inlier, 0 = outlier
inlier_mask = mask.ravel().tolist()

inliers = sum(inlier_mask)
outliers = len(inlier_mask) - inliers

print("Inliers:", inliers)
print("Outliers:", outliers)

# Draw only the inlier matches
match_view = cv2.drawMatches(
    img1,
    kp1,
    img2,
    kp2,
    good_matches,
    None,
    matchesMask=inlier_mask,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# Warp image 1 into image 2's coordinate system
height, width = img2.shape[:2]

warped = cv2.warpPerspective(
    img1,
    H,
    (width, height)
)

# Convert results to RGB
match_rgb = cv2.cvtColor(
    match_view, cv2.COLOR_BGR2RGB
)

warped_rgb = cv2.cvtColor(
    warped, cv2.COLOR_BGR2RGB
)

# Display
plt.figure(figsize=(14, 10))

plt.subplot(2, 1, 1)
plt.imshow(match_rgb)
plt.title("SIFT Inlier Matches after RANSAC")
plt.axis("off")

plt.subplot(2, 1, 2)
plt.imshow(warped_rgb)
plt.title("Image 1 Warped Using Homography")
plt.axis("off")

plt.tight_layout()
plt.show()

# Print homography matrix
print("\nHomography Matrix:")
print(H)
