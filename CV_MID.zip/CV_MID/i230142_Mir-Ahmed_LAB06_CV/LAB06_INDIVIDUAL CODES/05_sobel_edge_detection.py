# Sobel Edge Detection
# Sobel calculates intensity change in X and Y directions.

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert BGR image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Sobel X: detects changes in the X direction
sobel_x = cv2.Sobel(
    gray,
    cv2.CV_64F,  # keeps positive and negative values
    1,           # dx
    0,           # dy
    ksize=3      # 3x3 kernel
)

# Sobel Y: detects changes in the Y direction
sobel_y = cv2.Sobel(
    gray,
    cv2.CV_64F,
    0,
    1,
    ksize=3
)

# Combine X and Y gradients
magnitude = np.sqrt(
    sobel_x ** 2 + sobel_y ** 2
)

# Convert to normal image range (0-255)
magnitude = np.uint8(
    np.clip(magnitude, 0, 255)
)

# Convert original BGR to RGB for Matplotlib
image_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

# Display results
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(2, 2, 2)
plt.imshow(sobel_x, cmap="gray")
plt.title("Sobel X")
plt.axis("off")

plt.subplot(2, 2, 3)
plt.imshow(sobel_y, cmap="gray")
plt.title("Sobel Y")
plt.axis("off")

plt.subplot(2, 2, 4)
plt.imshow(magnitude, cmap="gray")
plt.title("Sobel Edge Magnitude")
plt.axis("off")

plt.tight_layout()
plt.show()
