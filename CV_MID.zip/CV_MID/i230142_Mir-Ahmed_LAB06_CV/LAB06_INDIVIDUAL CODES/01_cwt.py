# CWT - Continuous Wavelet Transform
# CWT is mainly used for analyzing a 1-D signal at different scales.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Use the middle row of the image as a 1-D signal
signal = gray[gray.shape[0] // 2, :].astype(float)

# Define scales
scales = np.arange(1, 64)

# Apply CWT
coefficients, frequencies = pywt.cwt(signal, scales, "mexh")

# Display the signal and CWT result
plt.figure(figsize=(10, 7))

plt.subplot(2, 1, 1)
plt.plot(signal)
plt.title("1-D Signal (Middle Row)")
plt.xlabel("Pixel Position")
plt.ylabel("Intensity")

plt.subplot(2, 1, 2)
plt.imshow(
    np.abs(coefficients),
    aspect="auto",
    cmap="gray",
    extent=[0, len(signal), scales[-1], scales[0]]
)
plt.title("Continuous Wavelet Transform (CWT)")
plt.xlabel("Pixel Position")
plt.ylabel("Scale")

plt.tight_layout()
plt.show()
