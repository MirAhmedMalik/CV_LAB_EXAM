# Inverse Wavelet Transform
# It reconstructs the image from its wavelet coefficients.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# First apply DWT
cA, (cH, cV, cD) = pywt.dwt2(gray, "haar")

# Now reconstruct the image using inverse DWT
reconstructed = pywt.idwt2(
    (cA, (cH, cV, cD)),
    "haar"
)

# Make values valid image pixels
reconstructed = np.clip(
    reconstructed, 0, 255
).astype(np.uint8)

# Display original and reconstructed image
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(gray, cmap="gray")
plt.title("Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(reconstructed, cmap="gray")
plt.title("Reconstructed")
plt.axis("off")

plt.tight_layout()
plt.show()
