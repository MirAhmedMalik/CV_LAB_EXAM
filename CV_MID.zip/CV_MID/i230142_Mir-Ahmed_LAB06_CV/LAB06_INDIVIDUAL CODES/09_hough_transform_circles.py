# Hough Transform - Circle Detection
#
# Main idea:
# Grayscale -> Blur -> HoughCircles -> Draw Circles

import cv2
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(
    image, cv2.COLOR_BGR2GRAY
)

# Blur to reduce noise
gray_blurred = cv2.GaussianBlur(
    gray,
    (9, 9),
    2
)

# Detect circles
circles = cv2.HoughCircles(
    gray_blurred,
    cv2.HOUGH_GRADIENT,  # detection method
    dp=1,
    minDist=20,
    param1=100,
    param2=30,
    minRadius=10,
    maxRadius=200
)

# Copy image for drawing
circle_image = image.copy()

if circles is not None:
    # Convert detected values to integers
    circles = circles[0].round().astype("int")

    print("Number of circles:", len(circles))

    for x, y, radius in circles:

        # Draw the circle
        cv2.circle(
            circle_image,
            (x, y),
            radius,
            (0, 255, 0),
            2
        )

        # Draw the center point
        cv2.circle(
            circle_image,
            (x, y),
            2,
            (0, 0, 255),
            3
        )
else:
    print("No circles detected.")

# Convert to RGB for Matplotlib
original_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

circle_rgb = cv2.cvtColor(
    circle_image, cv2.COLOR_BGR2RGB
)

# Display
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(original_rgb)
plt.title("Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(circle_rgb)
plt.title("Hough Circle Detection")
plt.axis("off")

plt.tight_layout()
plt.show()
