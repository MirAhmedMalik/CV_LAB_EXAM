# Canny Edge Detection
# Main idea:
# Blur -> Gradient -> Non-maximum Suppression -> Hysteresis

import cv2
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert BGR to RGB for Matplotlib
image_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

# Convert image to grayscale
gray = cv2.cvtColor(
    image, cv2.COLOR_BGR2GRAY
)

# Gaussian smoothing removes/reduces noise
blurred = cv2.GaussianBlur(
    gray,
    (5, 5),  # kernel size
    1.4      # sigma
)

# Canny performs the remaining edge-detection steps
edges = cv2.Canny(
    blurred,
    50,   # lower threshold
    150   # upper threshold
)

# Display results
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(2, 2, 2)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale")
plt.axis("off")

plt.subplot(2, 2, 3)
plt.imshow(blurred, cmap="gray")
plt.title("Gaussian Blurred")
plt.axis("off")

plt.subplot(2, 2, 4)
plt.imshow(edges, cmap="gray")
plt.title("Canny Edges")
plt.axis("off")

plt.tight_layout()
plt.show()
