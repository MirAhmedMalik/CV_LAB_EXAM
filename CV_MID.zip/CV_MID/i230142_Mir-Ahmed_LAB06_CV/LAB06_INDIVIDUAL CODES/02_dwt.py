# DWT - Discrete Wavelet Transform
# DWT splits an image into approximation and detail parts.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply 2-D DWT using Haar wavelet
cA, (cH, cV, cD) = pywt.dwt2(gray, "haar")

# cA = approximation (low-frequency information)
# cH = horizontal detail
# cV = vertical detail
# cD = diagonal detail

# Convert coefficients to displayable 0-255 images
def normalize_for_display(data):
    data = np.abs(data)
    return cv2.normalize(
        data, None, 0, 255, cv2.NORM_MINMAX
    ).astype(np.uint8)

cA_display = normalize_for_display(cA)
cH_display = normalize_for_display(cH)
cV_display = normalize_for_display(cV)
cD_display = normalize_for_display(cD)

# Display all parts
plt.figure(figsize=(10, 8))

plt.subplot(2, 3, 1)
plt.imshow(gray, cmap="gray")
plt.title("Original Grayscale")
plt.axis("off")

plt.subplot(2, 3, 2)
plt.imshow(cA_display, cmap="gray")
plt.title("Approximation (cA)")
plt.axis("off")

plt.subplot(2, 3, 3)
plt.imshow(cH_display, cmap="gray")
plt.title("Horizontal (cH)")
plt.axis("off")

plt.subplot(2, 3, 4)
plt.imshow(cV_display, cmap="gray")
plt.title("Vertical (cV)")
plt.axis("off")

plt.subplot(2, 3, 5)
plt.imshow(cD_display, cmap="gray")
plt.title("Diagonal (cD)")
plt.axis("off")

plt.tight_layout()
plt.show()
