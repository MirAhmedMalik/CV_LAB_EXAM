# WPT - Wavelet Packet Transform
# WPT is an extension of DWT and gives more detailed decomposition.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Create a 2-D Wavelet Packet decomposition
wp = pywt.WaveletPacket2D(
    data=gray,
    wavelet="haar",
    mode="symmetric",
    maxlevel=2
)

# Get all subbands at level 2
nodes = wp.get_level(2, order="natural")

print("Subbands at level 2:", len(nodes))
for node in nodes:
    print("Subband:", node.path)

# Display the subbands
plt.figure(figsize=(10, 10))

for i, node in enumerate(nodes):
    data = np.abs(node.data)

    data = cv2.normalize(
        data, None, 0, 255, cv2.NORM_MINMAX
    ).astype(np.uint8)

    plt.subplot(4, 4, i + 1)
    plt.imshow(data, cmap="gray")
    plt.title(node.path)
    plt.axis("off")

plt.tight_layout()
plt.show()
