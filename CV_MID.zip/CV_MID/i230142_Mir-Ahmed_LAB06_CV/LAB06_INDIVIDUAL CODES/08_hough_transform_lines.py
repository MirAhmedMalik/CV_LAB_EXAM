# Hough Transform - Line Detection
#
# Main idea:
# 1. Read image
# 2. Grayscale
# 3. Canny edges
# 4. Hough Transform
# 5. Draw detected lines

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE_PATH = "image.jpg"

# Read image
image = cv2.imread(IMAGE_PATH)
if image is None:
    raise FileNotFoundError(f"Cannot read image: {IMAGE_PATH}")

# Convert to grayscale
gray = cv2.cvtColor(
    image, cv2.COLOR_BGR2GRAY
)

# Detect edges first
edges = cv2.Canny(
    gray,
    50,
    150
)

# Copy original because we will draw lines on it
line_image = image.copy()

# Probabilistic Hough Transform
lines = cv2.HoughLinesP(
    edges,
    1,             # rho resolution in pixels
    np.pi / 180,   # theta resolution in radians
    threshold=80,  # minimum votes
    minLineLength=50,
    maxLineGap=10
)

# Draw detected lines
if lines is not None:
    print("Number of lines:", len(lines))

    for line in lines:
        x1, y1, x2, y2 = line[0]

        cv2.line(
            line_image,
            (x1, y1),
            (x2, y2),
            (0, 0, 255),
            2
        )
else:
    print("No lines detected.")

# Convert images to RGB for Matplotlib
original_rgb = cv2.cvtColor(
    image, cv2.COLOR_BGR2RGB
)

line_rgb = cv2.cvtColor(
    line_image, cv2.COLOR_BGR2RGB
)

# Display
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(original_rgb)
plt.title("Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(line_rgb)
plt.title("Hough Line Detection")
plt.axis("off")

plt.tight_layout()
plt.show()
