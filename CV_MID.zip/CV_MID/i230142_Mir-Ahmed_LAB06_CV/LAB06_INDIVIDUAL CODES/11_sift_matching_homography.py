# SIFT Feature Matching + RANSAC + Homography
#
# Covers:
# keypoint detection -> descriptors -> matching ->
# outlier rejection (RANSAC) -> homography

import cv2
import numpy as np
import matplotlib.pyplot as plt

IMAGE1_PATH = "image1.jpg"
IMAGE2_PATH = "image2.jpg"

# Read both images.
img1 = cv2.imread(IMAGE1_PATH)
img2 = cv2.imread(IMAGE2_PATH)

if img1 is None:
    raise FileNotFoundError(f"Cannot read: {IMAGE1_PATH}")

if img2 is None:
    raise FileNotFoundError(f"Cannot read: {IMAGE2_PATH}")

# Convert both images to grayscale.
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

# Create SIFT.
sift = cv2.SIFT_create()

# Find keypoints and descriptors.
kp1, des1 = sift.detectAndCompute(gray1, None)
kp2, des2 = sift.detectAndCompute(gray2, None)

print("Keypoints in image 1:", len(kp1))
print("Keypoints in image 2:", len(kp2))

if des1 is None or des2 is None:
    raise RuntimeError("SIFT did not find enough features.")

# BFMatcher + L2 distance is suitable for SIFT descriptors.
bf = cv2.BFMatcher(cv2.NORM_L2)

# Find the 2 nearest matches for each descriptor.
matches = bf.knnMatch(des1, des2, k=2)

# Lowe ratio test: keep better matches.
good_matches = []

for m, n in matches:
    if m.distance < 0.75 * n.distance:
        good_matches.append(m)

print("Good matches:", len(good_matches))

if len(good_matches) < 4:
    raise RuntimeError("At least 4 good matches are needed for homography.")

# Get matching point coordinates.
src_pts = np.float32([
    kp1[m.queryIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

dst_pts = np.float32([
    kp2[m.trainIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

# Estimate homography and reject outliers using RANSAC.
H, mask = cv2.findHomography(
    src_pts,
    dst_pts,
    cv2.RANSAC,
    5.0
)

if H is None or mask is None:
    raise RuntimeError("Homography could not be estimated.")

# mask: 1 = inlier, 0 = outlier
inlier_mask = mask.ravel().tolist()

inliers = sum(inlier_mask)
outliers = len(inlier_mask) - inliers

print("Inliers:", inliers)
print("Outliers:", outliers)

# Draw only inlier matches.
match_view = cv2.drawMatches(
    img1,
    kp1,
    img2,
    kp2,
    good_matches,
    None,
    matchesMask=inlier_mask,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# Warp image 1 into image 2 using the homography.
height, width = img2.shape[:2]

warped = cv2.warpPerspective(
    img1,
    H,
    (width, height)
)

# Display results.
plt.figure(figsize=(14, 10))

plt.subplot(2, 1, 1)
plt.imshow(cv2.cvtColor(match_view, cv2.COLOR_BGR2RGB))
plt.title("SIFT Inlier Matches after RANSAC")
plt.axis("off")

plt.subplot(2, 1, 2)
plt.imshow(cv2.cvtColor(warped, cv2.COLOR_BGR2RGB))
plt.title("Image 1 Warped using Homography")
plt.axis("off")

plt.tight_layout()
plt.savefig("sift_homography_result.png", dpi=150)
plt.show()

print("\nHomography matrix:")
print(H)
