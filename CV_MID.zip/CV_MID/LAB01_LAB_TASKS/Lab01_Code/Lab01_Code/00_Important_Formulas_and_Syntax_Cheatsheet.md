# Lab 01: Important Formulas + Syntax (exam quick sheet)

## Image basics
| Item | Formula / code |
|---|---|
| Shape | `h, w = img.shape[:2]` (colour = `(h, w, 3)`, gray = `(h, w)`) |
| Total pixels | `h * w` ; total values = `h * w * channels` |
| Size in bytes (uint8) | `h * w * channels` |
| Pixel access | `img[y, x]` (row first) -> `[B, G, R]` |
| Center point | `(w // 2, h // 2)` as (x, y) |
| Crop / ROI | `img[y1:y2, x1:x2]` |
| Center ROI of size S | `y1 = h//2 - S//2` , `x1 = w//2 - S//2` , `roi = img[y1:y1+S, x1:x1+S]` |
| Bottom P% of image | `y0 = int(h * (1 - P/100))` -> region `img[y0:h, :]` |
| Blank black image | `np.zeros((h, w, 3), np.uint8)` ; white: `np.full((h, w, 3), 255, np.uint8)` |
| Load gray | `cv2.imread(path, cv2.IMREAD_GRAYSCALE)` (or flag `0`) |
| Safe load | `if img is None: print("Error")` (wrong path gives `None`) |
| BGR to RGB | `cv2.cvtColor(img, cv2.COLOR_BGR2RGB)` (OpenCV = BGR, Matplotlib = RGB) |
| BGR to Gray | `cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)` ; Gray = 0.299 R + 0.587 G + 0.114 B |
| Resize | `cv2.resize(img, (width, height))` (width first!) |
| Split / merge channels | `b, g, r = cv2.split(img)` ; `cv2.merge([b, g, r])` |

## Drawing (colours are BGR, thickness -1 = filled)
```
cv2.line(img, (x1,y1), (x2,y2), color, thickness)
cv2.rectangle(img, (x1,y1), (x2,y2), color, thickness)        # top-left, bottom-right
cv2.circle(img, (cx,cy), radius, color, thickness)
cv2.fillPoly(img, [pts], color)                               # pts = np.array([[x,y],...], np.int32)
cv2.polylines(img, [pts], True, color, thickness)             # True = closed
cv2.putText(img, "text", (x,y), cv2.FONT_HERSHEY_SIMPLEX, fontScale, color, thickness, cv2.LINE_AA)
```
- Bounding box of a circle: `(cx-r, cy-r)` to `(cx+r, cy+r)`
- Common colours (BGR): red `(0,0,255)`, green `(0,255,0)`, blue `(255,0,0)`, white `(255,255,255)`, yellow `(0,255,255)`
- `putText` (x, y) = bottom-left corner of the text.

## Blur
- Gaussian blur: `cv2.GaussianBlur(img, (k, k), 0)` -> k must be **odd** (3, 5, 25...). Bigger k = more blur.
- Other blurs: `cv2.blur(img, (k,k))` (average), `cv2.medianBlur(img, k)`.

## Alpha blending / addWeighted
- `dst = alpha * img1 + beta * img2 + gamma`
- `cv2.addWeighted(img1, alpha, img2, beta, gamma)` -> both images must be the **same size**.
- Normal semi-transparent overlay: `beta = 1 - alpha`, `gamma = 0`.
- Bigger alpha for the overlay = overlay more visible.

## Thresholding
| Type | Rule / code |
|---|---|
| Global binary | pixel > T -> 255 else 0 : `_, out = cv2.threshold(gray, T, 255, cv2.THRESH_BINARY)` |
| Inverse binary | pixel > T -> 0 else 255 : `cv2.THRESH_BINARY_INV` |
| Otsu (auto T) | `cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)` |
| Adaptive | `cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, blockSize, C)` |
- Adaptive local threshold: `T(x,y) = (mean or gaussian-weighted mean of blockSize x blockSize area) - C`
- `blockSize` must be **odd** (>1). Mean method = `ADAPTIVE_THRESH_MEAN_C`.
- Use adaptive when lighting is uneven; global when lighting is uniform.

## Rotation (affine)
- `M = cv2.getRotationMatrix2D((cx, cy), angle, scale)` -> returns 2x3 matrix. Positive angle = **counter-clockwise**.
- `out = cv2.warpAffine(img, M, (w, h))` -> size is (width, height).
- Matrix: with `a = scale*cos(angle)`, `b = scale*sin(angle)`:
  `M = [[a, b, (1-a)*cx - b*cy], [-b, a, b*cx + (1-a)*cy]]`
- Scale < 1 (e.g. 0.8) shrinks the image so the corners are not cut after rotation.

## Bitwise operations (work on pixels / masks)
| Function | Result |
|---|---|
| `cv2.bitwise_and(a, b, mask=m)` | keep pixels where mask is white (255) |
| `cv2.bitwise_or(a, b)` | combine (white if either is white) |
| `cv2.bitwise_not(m)` | invert (255 - value) |
| `cv2.bitwise_xor(a, b)` | white where they differ |
- Cut-out pattern: `fg = and(img1, img1, mask)` , `bg = and(img2, img2, not(mask))` , `result = or(fg, bg)`
- Both images and the mask must have the **same size**; mask is 1-channel uint8.

## Matplotlib
```
plt.figure(figsize=(w, h))            # size in inches
plt.subplot(rows, cols, position)     # position starts at 1
plt.imshow(img)                       # colour (RGB) ; gray -> cmap="gray"
plt.title("text", fontsize=16, color="darkred", pad=15)
plt.axis("off")                       # hide axes
plt.show()
```

## NumPy / Pandas statistics
- Mean = sum(x) / n
- Standard deviation = sqrt( sum((x - mean)^2) / n )   (pandas `std()` uses n-1, NumPy `np.std` uses n)
- Flatten: `arr.flatten()` or `arr.ravel()` -> (H, W) becomes (H*W,)
- `df = pd.DataFrame({"Red": r, "Green": g, "Blue": b})`
- `df.describe()` gives: count, mean, std, min, 25%, 50%, 75%, max
- Channel order after BGR to RGB: `img[:,:,0]` = Red, `[:,:,1]` = Green, `[:,:,2]` = Blue (in raw OpenCV BGR: 0 = Blue).

## Python OOP / dict reminders
- Class: `class A:` with `def __init__(self):` ; methods use `self`.
- Total cost = sum(quantity * price) over all items.
- Highest average: `max(d, key=lambda k: average(d[k]["Grades"]))` ; average = `sum(g) / len(g)`.
- Remove safely: `if key in d: del d[key] else: print("Error")`.
