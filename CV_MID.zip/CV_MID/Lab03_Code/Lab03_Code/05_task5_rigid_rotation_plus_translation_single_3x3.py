# FILE 05 | Task 5: Rigid = Rotation + Translation in ONE 3x3 matrix (shape and size preserved)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]
cx, cy = w / 2, h / 2

def T(tx, ty):                                 # 3x3 translation
    return np.float32([[1, 0, tx], [0, 1, ty], [0, 0, 1]])

def R(deg):                                    # 3x3 rotation (counter-clockwise)
    t = np.deg2rad(deg); c, s = np.cos(t), np.sin(t)
    return np.float32([[c, s, 0], [-s, c, 0], [0, 0, 1]])

angle, tx, ty = -30, 40, -20                   # chip is rotated sideways and off-center
# order (right to left): move center to origin -> rotate -> move back -> translate
M = T(tx, ty) @ T(cx, cy) @ R(angle) @ T(-cx, -cy)

aligned = cv2.warpAffine(img, M[:2], (w, h))   # apply once

# Rigid: no scaling, so det of top-left 2x2 = 1
print(np.linalg.det(M[:2, :2]))

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(aligned, cv2.COLOR_BGR2RGB)); plt.title('Rigid'); plt.axis('off')
plt.show()
