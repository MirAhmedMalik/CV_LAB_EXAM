# FILE 14 | Reflection (flip) with matrix + composition order check + point transform
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]

# Reflection across Y-axis (horizontal flip): x' = -x  (+ w-1 so it stays visible)
Mx = np.float32([[-1, 0, w - 1], [0, 1, 0]])
flip_h = cv2.warpAffine(img, Mx, (w, h))       # same as cv2.flip(img, 1)

# Reflection across X-axis (vertical flip): y' = -y
My = np.float32([[1, 0, 0], [0, -1, h - 1]])
flip_v = cv2.warpAffine(img, My, (w, h))       # same as cv2.flip(img, 0)
# cv2.flip codes: 1 = horizontal, 0 = vertical, -1 = both

# Composition order matters: A @ B is NOT B @ A
T = np.float32([[1, 0, 50], [0, 1, 0], [0, 0, 1]])
R = np.float32([[0, 1, 0], [-1, 0, 0], [0, 0, 1]])           # 90 deg rotation
p = np.array([10, 0, 1])
print('rotate then translate:', T @ R @ p)     # R applied first
print('translate then rotate:', R @ T @ p)     # T applied first -> different result

# Transform a list of points with a 3x3 matrix
pts = np.float32([[[0, 0]], [[100, 0]]])       # shape (N,1,2)
print(cv2.perspectiveTransform(pts, T))

plt.figure(figsize=(12, 4))
for i, (im, t) in enumerate([(img, 'Original'), (flip_h, 'Flip H'), (flip_v, 'Flip V')]):
    plt.subplot(1, 3, i + 1); plt.imshow(cv2.cvtColor(im, cv2.COLOR_BGR2RGB)); plt.title(t); plt.axis('off')
plt.show()
