# FILE 07 | Task 7: General Affine - solve 6 unknowns from 3 point pairs (np.linalg.solve)
import cv2
import numpy as np
import matplotlib.pyplot as plt

glitched = cv2.imread('image.jpg')             # the corrupted photo
h, w = glitched.shape[:2]

# 3 landmarks: position in the ORIGINAL photo and in the GLITCHED photo (x, y)
orig_pts = np.float32([[50, 50], [300, 60], [60, 250]])
glit_pts = np.float32([[80, 40], [330, 120], [60, 260]])

def solve_affine(src, dst):
    # u = a*x + b*y + c   and   v = d*x + e*y + f  ->  6 equations, 6 unknowns
    A, b = [], []
    for (x, y), (u, v) in zip(src, dst):
        A.append([x, y, 1, 0, 0, 0]); b.append(u)
        A.append([0, 0, 0, x, y, 1]); b.append(v)
    p = np.linalg.solve(np.array(A, float), np.array(b, float))
    return p.reshape(2, 3).astype(np.float32)  # [[a,b,c],[d,e,f]]

M = solve_affine(glit_pts, orig_pts)           # to FIX: map glitched -> original
print(M)
print(cv2.getAffineTransform(glit_pts, orig_pts))   # built-in check (same answer)

fixed = cv2.warpAffine(glitched, M, (w, h))

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(glitched, cv2.COLOR_BGR2RGB)); plt.title('Glitched'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB)); plt.title('Fixed'); plt.axis('off')
plt.show()
