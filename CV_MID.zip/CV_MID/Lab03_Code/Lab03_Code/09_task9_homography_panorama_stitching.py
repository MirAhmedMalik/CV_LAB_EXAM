# FILE 09 | Task 9: Homography - stitch image 2 into image 1 space (panorama)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img1 = cv2.imread('img1.jpg')                  # left camera (reference)
img2 = cv2.imread('img2.jpg')                  # right camera (to be warped)
h1, w1 = img1.shape[:2]
h2, w2 = img2.shape[:2]

# 4 matching points: same real-world spots in both photos (x, y)
pts1 = np.float32([[300, 50], [390, 60], [395, 240], [305, 250]])   # in img1
pts2 = np.float32([[10, 55], [100, 62], [105, 245], [15, 255]])     # in img2

H = cv2.getPerspectiveTransform(pts2, pts1)    # img2 -> img1 space (order: src, dst)
# Many matches: H, mask = cv2.findHomography(pts2, pts1, cv2.RANSAC, 5.0)

canvas = (w1 + w2, max(h1, h2))               # wide enough for both
pano = cv2.warpPerspective(img2, H, canvas)   # project img2
pano[0:h1, 0:w1] = img1                        # paste img1 on top

plt.figure(figsize=(14, 4))
plt.imshow(cv2.cvtColor(pano, cv2.COLOR_BGR2RGB)); plt.title('Panorama'); plt.axis('off')
plt.show()
