# LAB 03: Geometric Transformations - MCQ Concepts + Code Finder

## 1. Geometric vs Photometric
| | Geometric | Photometric |
|---|---|---|
| Changes | **WHERE** the pixel is (position) | **WHAT** the pixel looks like (value) |
| Formula | (x, y) -> (x', y') | I(x,y) -> I'(x,y) |
| Examples | rotate, scale, shear, translate, perspective | brightness, contrast, gamma, histogram, colour conversion |

Geometric transformation = changes position, orientation, scale or shape **without changing pixel data values**.

## 2. Image Coordinate System
- Origin (0,0) = **top-left**. x -> right, **y -> down** (not like maths graph).
- Image 640x480: corners (0,0), (639,0), (0,479), (639,479).
- Access pixel: `image[y, x]` (row first). Point is written (x, y).
- `image.shape` = **(height, width, channels)**, but OpenCV size arguments = **(width, height)**.
- OpenCV positive angle = **counter-clockwise** (it accounts for top-left origin).
- Colour order is **BGR**; matplotlib needs RGB.

## 3. 2D vs 3D
| | 2D | 3D |
|---|---|---|
| Point | (x, y) -> (x', y') | (x,y,z) -> (x',y',z') |
| Matrix | **2x3** affine or **3x3** homogeneous | **4x4** homogeneous |
| Used for | image plane, photo, document | robotics, 3D graphics |
- `warpAffine` takes **2x3**. `warpPerspective` takes **3x3**.

## 4. Transformation Matrix [[a, b], [c, d]]
- Read **columns**: column 1 (a, c) = where the X-axis lands; column 2 (b, d) = where the Y-axis lands. Identity = [[1,0],[0,1]].

| Variable | Controls |
|---|---|
| **a** | Horizontal scale (x of x-axis). Negative = flip horizontally |
| **d** | Vertical scale (y of y-axis). Negative = flip vertically |
| **b** | Horizontal shear (x of y-axis) |
| **c** | Vertical shear (y of x-axis) |
- Pure rotation needs **all four** values changed together (sin and cos).
- x' = ax + by , y' = cx + dy.

## 5. The Matrices (MEMORIZE)
| Transform | Matrix | Notes |
|---|---|---|
| Scale | [[sx,0],[0,sy]] | diagonal; sx=sy = uniform |
| Rotation | [[cos t, -sin t],[sin t, cos t]] | keeps axes perpendicular |
| Reflection (over X-axis) | [[1,0],[0,-1]] | negative on diagonal |
| Horizontal shear | [[1,k],[0,1]] | x' = x + k*y |
| Translation (3x3) | [[1,0,tx],[0,1,ty],[0,0,1]] | needs homogeneous |
| Projective H | 3x3, 8 free values (h33 = 1) | x' = (h11x+h12y+h13)/(h31x+h32y+h33) |

OpenCV `getRotationMatrix2D` gives [[cos, sin, ...],[-sin, cos, ...]] (counter-clockwise for positive angle).

## 6. Hierarchy (very important)
```
2D Geometric
 |- AFFINE
 |   |- LINEAR: Rotation, Scale, Shear   (no translation)
 |   |     |- Similarity (scale+rotation+translation, angles kept)
 |   |           |- Rigid (rotation+translation, scale = 1)
 |   |- Translation
 |- PROJECTIVE (Homography)
      |- Perspective
```
| Type | Allowed | Preserves | Degrees of freedom | Points needed |
|---|---|---|---|---|
| Translation | move | everything except position | 2 | 1 |
| **Rigid** | rotate + translate | **lengths, angles**, shape | 3 | 2 |
| **Similarity** | + uniform scale | **angles**, ratios (not lengths) | 4 | 2 |
| **Affine** | + shear, non-uniform scale | **parallelism, collinearity**, ratio of distances on a line | 6 | **3** |
| **Projective** | + perspective | **collinearity only** (parallel lines can meet) | 8 | **4** |
- Each type contains the one below it (Rigid is a special Similarity, Similarity is a special Affine, Affine is a special Projective).
- Affine matrix bottom row = **[0, 0, 1]** -> denominator always 1.
- Projective bottom row has h31, h32 -> denominator changes with position -> **depth/perspective**.

## 7. Linear vs Affine
- **Linear:** p' = A p. Origin stays fixed: A * (0,0) = (0,0). **Cannot translate.** Does rotate, scale, shear, reflect.
- **Affine:** p' = A p + b (linear + translation).
- **Homogeneous coordinates:** (x, y) -> (x, y, 1). Translation becomes matrix multiplication, so many transforms combine into **one master matrix**.
- Matrix multiplication is **not commutative**: T @ R is not R @ T. In `T @ R @ S`, **S is applied first** (right to left).
- Rotate around the centre: `T(c) @ R @ T(-c)`.

## 8. Projective (Homography) facts
- Simulates 3D perspective: parallel lines converge (vanishing point).
- Divide by w' to get final coordinates (normalize).
- Used for: bird's-eye view, document scanning (trapezoid -> rectangle), panorama stitching.
- Needs **4 point pairs** (8 equations, 8 unknowns).

## 9. OpenCV Functions
| Need | Code | Remember |
|---|---|---|
| Rotation matrix | `cv2.getRotationMatrix2D(center, angle, scale)` | center = (x, y); returns **2x3** |
| Apply affine | `cv2.warpAffine(img, M, (w, h))` | M = 2x3, dsize = (width, height) |
| Resize / scale | `cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_LINEAR)` | or `cv2.resize(img, (new_w, new_h))` |
| Affine from 3 pairs | `cv2.getAffineTransform(src3, dst3)` | float32, shape (3,2) |
| Perspective from 4 pairs | `cv2.getPerspectiveTransform(src4, dst4)` | float32, shape (4,2), returns 3x3 |
| Apply perspective | `cv2.warpPerspective(img, H, (w, h))` | H = 3x3 |
| Many matches | `cv2.findHomography(pts2, pts1, cv2.RANSAC)` | removes bad matches |
| Transform points | `cv2.perspectiveTransform(pts, H)` | pts shape (N,1,2) |
| Flip | `cv2.flip(img, code)` | 1 = horizontal, 0 = vertical, -1 = both |
| Points type | `np.float32([...])` | float32 is required |
- Empty areas after warp become **black**.
- Interpolation: `INTER_NEAREST` (fast), `INTER_LINEAR` (default), `INTER_CUBIC` (best for enlarging).
- **Inverse mapping**: output pixel -> find source pixel using inverse matrix (no holes). Forward mapping leaves holes.

## 10. Formulas for numeric questions
| Question | Formula |
|---|---|
| Keep centre fixed while scaling | tx = cx(1 - sx), ty = cy(1 - sy) |
| New size after rotation by t | new_w = w\|cos t\| + h\|sin t\| , new_h = h\|cos t\| + w\|sin t\| |
| New width after x-shear k | new_w = w + \|k\| * h |
| Translation by (tx, ty) | x' = x + tx , y' = y + ty |
| Apply matrix to point | [x', y', 1]^T = M [x, y, 1]^T |
| Combined rigid about centre | M = T(tx,ty) @ T(c) @ R @ T(-c) |
| Rigid check | det of top-left 2x2 = 1 |
| Affine solve | 3 points x 2 equations = 6 equations, 6 unknowns (a,b,c,d,e,f) |
| Homography solve | 4 points x 2 equations = 8 equations, 8 unknowns |

## 11. Quick MCQ Table
| Question | Answer |
|---|---|
| Linear transform keeps which point fixed? | Origin (0,0) |
| Can a 2x2 matrix translate? | No -> use 3x3 homogeneous |
| Why homogeneous coordinates? | Do translation with multiplication; combine all into one matrix |
| Affine preserves? | Parallelism + collinearity |
| Projective does NOT preserve? | Parallelism |
| Rigid transform changes size? | No |
| Similarity changes angles? | No (changes size only) |
| Shear changes? | Angles/shape (square -> parallelogram) |
| Rotation matrix determinant | 1 |
| Reflection matrix determinant | -1 |
| Scale matrix determinant | sx * sy |
| Min points for affine / perspective | 3 / 4 |
| warpAffine matrix size | 2x3 |
| warpPerspective matrix size | 3x3 |
| `image[y, x]` order | row (y) first |
| Geometric transform changes pixel values? | No, only positions (resampling may interpolate) |
| 3D homogeneous matrix size | 4x4 |
| Affine bottom row | [0, 0, 1] |
| Which has 8 DOF? | Projective (homography) |
| Which has 6 DOF? | Affine |
| Translation is linear? | No, it is affine |

## 12. Which file to open in the exam
| If the question says... | Open |
|---|---|
| Scale / enlarge / resize, keep centered, manual 2x2 scale matrix | `01_task1_scale_manual_matrix_keep_centered.py` |
| Rotate image, sin/cos matrix, corners cut, new dimensions | `02_task2_rotation_manual_sin_cos_no_crop.py` |
| Shear, slanted, barcode, push pixels horizontally | `03_task3_shear_fix_slanted_barcode.py` |
| Translation, shift, move, 3x3 matrix, homogeneous | `04_task4_translation_3x3_homogeneous.py` |
| Rigid = rotation + translation in one matrix | `05_task5_rigid_rotation_plus_translation_single_3x3.py` |
| Similarity = scale + rotation + translation | `06_task6_similarity_scale_rotation_translation_single_3x3.py` |
| General affine, 3 points, solve equations, 6 unknowns | `07_task7_general_affine_solve_6_unknowns_from_3_points.py` |
| Perspective, bird's-eye, 4 corners to square, solve 8 unknowns | `08_task8_perspective_birdseye_4_points.py` |
| Homography, panorama, stitch two images | `09_task9_homography_panorama_stitching.py` |
| Full hierarchy, insert image into frame, scale + rigid + projective | `10_task10_master_forger_scale_rigid_projective_chain.py` |
| Load image, None check, BGR to RGB, show before/after | `11_basic_template_load_check_show.py` |
| Simple built-in OpenCV example (rotation, scale, shear, translation, rigid, perspective) | `12_lab_manual_builtin_opencv_all_transforms.py` |
| Without warpAffine, manual pixel mapping, inverse mapping | `13_manual_warp_inverse_mapping_no_warpAffine.py` |
| Reflection, flip, order of matrix multiplication, transform points | `14_reflection_flip_and_matrix_composition_check.py` |

### Exam-day tips
1. Change only the file names, angle, scale, shear value and the point coordinates. Image names used in the code: `image.jpg`, `img1.jpg`, `img2.jpg`, `painting.jpg`, `wall.jpg`.
2. Black output or crash with `NoneType` -> wrong image path (`imread` gives None).
3. Image cut off -> bigger `dsize` (see formulas in section 10).
4. Rotation looks the wrong way -> flip the sign of the angle (positive = counter-clockwise).
5. Shear looks worse -> flip the sign of `k`.
6. Point coordinates: open the image with `plt.imshow` and read x, y from the axes. Order of points must match in source and destination (TL, TR, BR, BL).
7. Points must be `np.float32`, matrix for `warpAffine` must be 2x3, not 3x3 (use `M[:2]`).
