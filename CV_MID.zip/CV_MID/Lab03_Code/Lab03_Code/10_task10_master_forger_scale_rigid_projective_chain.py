# FILE 10 | Task 10: Full hierarchy - Linear Scale -> Rigid -> Projective (painting into angled frame)
import cv2
import numpy as np
import matplotlib.pyplot as plt

paint = cv2.imread('painting.jpg')
wall = cv2.imread('wall.jpg')
ph, pw = paint.shape[:2]
H_, W_ = wall.shape[:2]

def T(tx, ty):
    return np.float32([[1, 0, tx], [0, 1, ty], [0, 0, 1]])
def R(deg):
    t = np.deg2rad(deg); c, s = np.cos(t), np.sin(t)
    return np.float32([[c, s, 0], [-s, c, 0], [0, 0, 1]])
def S(sc):
    return np.float32([[sc, 0, 0], [0, sc, 0], [0, 0, 1]])

# Step 1: linear scale (shrink)   Step 2: rigid move (rotate + translate) near the frame
M1 = T(200, 100) @ R(0) @ S(0.5)

# Where did the 4 painting corners land after steps 1-2?
corners = np.float32([[0, 0], [pw - 1, 0], [pw - 1, ph - 1], [0, ph - 1]]).reshape(-1, 1, 2)
moved = cv2.perspectiveTransform(corners, M1).reshape(4, 2)

# Step 3: projective - map those corners to the 4 corners of the angled frame (TL, TR, BR, BL)
frame = np.float32([[210, 120], [420, 90], [430, 300], [200, 280]])
P = cv2.getPerspectiveTransform(moved, frame)

Final = P @ M1                                  # one master matrix
warped = cv2.warpPerspective(paint, Final, (W_, H_))
mask = cv2.warpPerspective(np.full((ph, pw), 255, np.uint8), Final, (W_, H_))   # painting area

out = wall.copy()
out[mask > 0] = warped[mask > 0]                # paste only the painting pixels

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(wall, cv2.COLOR_BGR2RGB)); plt.title('Wall'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB)); plt.title('Forged'); plt.axis('off')
plt.show()
