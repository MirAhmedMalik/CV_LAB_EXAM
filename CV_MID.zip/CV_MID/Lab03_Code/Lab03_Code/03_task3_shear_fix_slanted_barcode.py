# FILE 03 | Task 3: Shear (Linear) - push pixels horizontally to un-slant a barcode
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]
k = 0.3                                        # shear factor (if it gets worse, use -0.3)

# x' = x + k*y   ,   y' = y
Sh = np.float32([[1, k], [0, 1]])              # 2x2 horizontal shear matrix
tx = -k * h if k < 0 else 0                    # shift so nothing goes off the left side
M = np.float32([[1, k, tx],
                [0, 1, 0]])
new_w = int(w + abs(k) * h)                    # wider canvas so nothing is cut

fixed = cv2.warpAffine(img, M, (new_w, h))

# Vertical shear (y' = y + k*x) would be: M = np.float32([[1,0,0],[k,1,0]])

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Slanted'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB)); plt.title('After shear'); plt.axis('off')
plt.show()
