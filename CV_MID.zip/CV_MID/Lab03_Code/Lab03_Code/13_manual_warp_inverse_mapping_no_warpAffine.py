# FILE 13 | Apply ANY 3x3 transform manually (inverse mapping, nearest neighbour) - no warpAffine
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]

t = np.deg2rad(30); c, s = np.cos(t), np.sin(t)
M = np.float32([[c, s, 50],
                [-s, c, 20],
                [0, 0, 1]])                    # forward matrix (rotate 30 + move)

out = np.zeros_like(img)                       # black output, same size
ys, xs = np.indices((h, w))                    # every output pixel position
pts = np.stack([xs.ravel(), ys.ravel(), np.ones(h * w)])   # 3 x N homogeneous points

src = np.linalg.inv(M) @ pts                   # inverse: where does each output pixel come from?
sx = np.round(src[0]).astype(int)              # nearest neighbour
sy = np.round(src[1]).astype(int)
ok = (sx >= 0) & (sx < w) & (sy >= 0) & (sy < h)           # keep only points inside the input

out[ys.ravel()[ok], xs.ravel()[ok]] = img[sy[ok], sx[ok]]  # copy pixels
# Why inverse? Forward mapping leaves holes; inverse mapping fills every output pixel.

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB)); plt.title('Manual warp'); plt.axis('off')
plt.show()
