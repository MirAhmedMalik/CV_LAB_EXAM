# FILE 01 | Task 1: Scale (Linear) - manual 2x2 matrix, keep image centered
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]
cx, cy = w / 2, h / 2                          # image center
sx, sy = 3, 3                                  # 300% on x and y

S = np.float32([[sx, 0], [0, sy]])             # 2x2 scaling matrix
# Scaling grows from (0,0). To keep the center fixed: t = c - S*c
tx = cx - sx * cx
ty = cy - sy * cy
M = np.hstack([S, [[tx], [ty]]]).astype(np.float32)   # 2x3 for warpAffine

centered = cv2.warpAffine(img, M, (w, h))      # same canvas, zoomed at center
# Option B: whole enlarged image (bigger canvas, no cropping)
big = cv2.warpAffine(img, np.float32([[sx, 0, 0], [0, sy, 0]]), (int(w * sx), int(h * sy)))
# Option C (built-in): big = cv2.resize(img, None, fx=sx, fy=sy, interpolation=cv2.INTER_LINEAR)

imgs = [img, centered, big]
titles = ['Original', 'Scaled 3x, centered', 'Scaled 3x, full']
plt.figure(figsize=(14, 4))
for i in range(3):
    plt.subplot(1, 3, i + 1); plt.imshow(cv2.cvtColor(imgs[i], cv2.COLOR_BGR2RGB)); plt.title(titles[i]); plt.axis('off')
plt.show()
