# FILE 11 | Basic template: load, None-check, shape, BGR->RGB, show (start every question from this)
import cv2
import numpy as np
import matplotlib.pyplot as plt

image = cv2.imread('image.jpg')                # BGR, shape = (height, width, 3)
if image is None:
    print('Error: image.jpg not found')        # wrong path -> None
else:
    height, width = image.shape[:2]            # NOTE: shape is (h, w), cv2 size args are (w, h)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    print(height, width, image[0, 0])          # image[y, x] -> pixel at row y, column x

    plt.imshow(image_rgb); plt.title('Original'); plt.axis('off'); plt.show()

# Helper to show before/after
def show(a, b, t1='Before', t2='After'):
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(a, cv2.COLOR_BGR2RGB)); plt.title(t1); plt.axis('off')
    plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(b, cv2.COLOR_BGR2RGB)); plt.title(t2); plt.axis('off')
    plt.tight_layout(); plt.show()
