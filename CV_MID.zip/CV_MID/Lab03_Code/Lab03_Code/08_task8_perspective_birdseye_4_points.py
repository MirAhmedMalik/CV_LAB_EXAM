# FILE 08 | Task 8: Perspective - 4 corners -> perfect square (bird's-eye view)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')

# 4 corners of the art in the photo (x, y): TL, TR, BR, BL  (read from plt.imshow axes)
src = np.float32([[120, 80], [280, 80], [350, 250], [50, 250]])
size = 400
dst = np.float32([[0, 0], [size, 0], [size, size], [0, size]])   # perfect square

M = cv2.getPerspectiveTransform(src, dst)      # 3x3 homography
birdseye = cv2.warpPerspective(img, M, (size, size))

# Manual version: 8 unknowns (h33 = 1), 4 points x 2 equations
def solve_homography(s, d):
    A, b = [], []
    for (x, y), (u, v) in zip(s, d):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); b.append(v)
    h = np.linalg.solve(np.array(A, float), np.array(b, float))
    return np.append(h, 1).reshape(3, 3)
print(solve_homography(src, dst))              # same as M

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(birdseye, cv2.COLOR_BGR2RGB)); plt.title("Bird's-eye"); plt.axis('off')
plt.show()
