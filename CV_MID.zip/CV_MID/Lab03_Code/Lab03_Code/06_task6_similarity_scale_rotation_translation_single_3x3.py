# FILE 06 | Task 6: Similarity = Scale + Rotation + Translation in ONE 3x3 matrix (angles preserved)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]

def T(tx, ty):
    return np.float32([[1, 0, tx], [0, 1, ty], [0, 0, 1]])

def R(deg):
    t = np.deg2rad(deg); c, s = np.cos(t), np.sin(t)
    return np.float32([[c, s, 0], [-s, c, 0], [0, 0, 1]])

def S(sc):                                     # UNIFORM scale (same on x and y)
    return np.float32([[sc, 0, 0], [0, sc, 0], [0, 0, 1]])

scale, angle = 2.0, -30                        # blueprint too small and rotated
tx, ty = 50, 100                               # move to the right corner
M = T(tx, ty) @ R(angle) @ S(scale)            # applied right to left: scale -> rotate -> translate

canvas = (int(w * 2), int(h * 2))              # bigger canvas so it is not cut
fixed = cv2.warpAffine(img, M[:2], canvas)

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB)); plt.title('Similarity'); plt.axis('off')
plt.show()
