# FILE 04 | Task 4: Translation (Affine) - 3x3 matrix, slide map right 150 and down 80
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]
tx, ty = 150, 80                               # X was 150 left and 80 up -> move +150 right, +80 down

T = np.float32([[1, 0, tx],
                [0, 1, ty],
                [0, 0, 1]])                    # 3x3 homogeneous translation matrix

moved = cv2.warpAffine(img, T[:2], (w, h))     # warpAffine needs only top 2 rows (2x3)

# Check with one point: (x,y,1) -> (x+tx, y+ty, 1)
print(T @ np.array([10, 20, 1]))               # [160. 100. 1.]

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(moved, cv2.COLOR_BGR2RGB)); plt.title('Translated'); plt.axis('off')
plt.show()
