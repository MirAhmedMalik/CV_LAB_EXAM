# FILE 12 | Lab manual examples with built-in OpenCV: rotation, scale, shear, translation, rigid, perspective
import cv2
import numpy as np
import matplotlib.pyplot as plt

image = cv2.imread('image.jpg')
height, width = image.shape[:2]

def show(a, b, t2):
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(a, cv2.COLOR_BGR2RGB)); plt.title('Before'); plt.axis('off')
    plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(b, cv2.COLOR_BGR2RGB)); plt.title(t2); plt.axis('off')
    plt.tight_layout(); plt.show()

# ---- 1) ROTATION ----
center = (width // 2, height // 2)
M = cv2.getRotationMatrix2D(center, 45, 1.0)        # (center, angle, scale) angle>0 = counter-clockwise
rotated = cv2.warpAffine(image, M, (width, height))
show(image, rotated, 'Rotation 45')

# ---- 2) SCALE ----
scaled = cv2.resize(image, None, fx=3, fy=3, interpolation=cv2.INTER_LINEAR)
show(image, scaled, 'Scale 3x')

# ---- 3) SHEAR (x-shear) ----
kx = 0.5
M = np.float32([[1, kx, 0], [0, 1, 0]])
sheared = cv2.warpAffine(image, M, (int(width + abs(kx) * height), height))   # new width avoids cutting
show(image, sheared, 'X-shear')

# ---- 4) TRANSLATION ----
tx, ty = 100, 50
M = np.float32([[1, 0, tx], [0, 1, ty]])
translated = cv2.warpAffine(image, M, (width, height))
show(image, translated, 'Translation (100,50)')

# ---- 5) RIGID (rotation + translation, scale MUST be 1.0) ----
M = cv2.getRotationMatrix2D(center, 30, 1.0)
M[0, 2] += 100                                       # add tx
M[1, 2] += 50                                        # add ty
rigid = cv2.warpAffine(image, M, (width, height))
show(image, rigid, 'Rigid')

# ---- 6) PERSPECTIVE ----
src_points = np.float32([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]])
dst_points = np.float32([[100, 50], [width - 150, 0], [width - 50, height - 80], [50, height - 20]])
M = cv2.getPerspectiveTransform(src_points, dst_points)
perspective = cv2.warpPerspective(image, M, (width, height))
show(image, perspective, 'Perspective')
