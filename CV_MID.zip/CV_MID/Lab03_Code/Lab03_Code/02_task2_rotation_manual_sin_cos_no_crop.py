# FILE 02 | Task 2: Rotation (Linear) - manual sin/cos matrix + new size so corners are NOT cut
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
h, w = img.shape[:2]
angle = -45                                    # undo a +45 tilt (if wrong direction use +45)

t = np.deg2rad(angle)
c, s = np.cos(t), np.sin(t)
R = np.float32([[c, s], [-s, c]])              # rotation matrix (counter-clockwise, same as OpenCV)

# New size that fits the whole rotated image
new_w = int(abs(w * c) + abs(h * s))
new_h = int(abs(h * c) + abs(w * s))

# Rotate around center, then move the center to the new canvas center
cx, cy = w / 2, h / 2
tx = new_w / 2 - (R[0, 0] * cx + R[0, 1] * cy)
ty = new_h / 2 - (R[1, 0] * cx + R[1, 1] * cy)
M = np.float32([[R[0, 0], R[0, 1], tx],
                [R[1, 0], R[1, 1], ty]])

rotated = cv2.warpAffine(img, M, (new_w, new_h))   # dsize = (width, height)
# Built-in: M = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)  (needs same size fix)

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(rotated, cv2.COLOR_BGR2RGB)); plt.title(f'Rotated {angle} deg'); plt.axis('off')
plt.show()
