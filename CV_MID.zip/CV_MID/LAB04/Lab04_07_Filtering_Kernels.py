"""
LAB 04 - 07 : Filtering (kernels applied with cv2.filter2D)
Filter = small matrix (kernel). Slide over image, multiply element-wise, sum.
Blur kernels sum to 1. Edge kernels sum to 0.
"""
import cv2
import numpy as np

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH)                              # color
gray = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)         # gray

# ---------------- Box Blur (average) ----------------
kernel_box = np.ones((3, 3), dtype=np.float32) / 9
blurred_image = cv2.filter2D(image, -1, kernel_box)
blurred_builtin = cv2.blur(image, (3, 3))

# ---------------- Gaussian Blur ----------------
# getGaussianKernel gives a 1D column -> outer product makes the 2D kernel
k1d = cv2.getGaussianKernel(5, 1.0)                        # size 5, sigma 1.0
kernel_gauss = k1d @ k1d.T
gaussian_blur = cv2.filter2D(image, -1, kernel_gauss)
gaussian_builtin = cv2.GaussianBlur(image, (5, 5), 1.0)

# ---------------- Median Blur (best for salt & pepper noise) ----------------
median_blur = cv2.medianBlur(image, 5)

# ---------------- Bilateral (smooth but keep edges) ----------------
bilateral = cv2.bilateralFilter(image, 9, 75, 75)

# ---------------- Sobel (first derivative) ----------------
sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)       # vertical edges
sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)       # horizontal edges
sobel_mag = cv2.convertScaleAbs(np.sqrt(sobel_x ** 2 + sobel_y ** 2))

# ---------------- Scharr (more accurate than 3x3 Sobel) ----------------
scharr_x = cv2.Scharr(gray, cv2.CV_64F, 1, 0)
scharr_y = cv2.Scharr(gray, cv2.CV_64F, 0, 1)

# ---------------- Prewitt (not built in -> use filter2D) ----------------
prewitt_kx = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=np.float32)
prewitt_ky = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]], dtype=np.float32)
prewitt_x = cv2.filter2D(gray, cv2.CV_64F, prewitt_kx)
prewitt_y = cv2.filter2D(gray, cv2.CV_64F, prewitt_ky)

# ---------------- Laplacian (second derivative) ----------------
laplacian = cv2.Laplacian(gray, cv2.CV_64F)
kernel_lap = np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=np.float32)
laplacian_manual = cv2.filter2D(gray, cv2.CV_64F, kernel_lap)

# ---------------- Sharpen ----------------
kernel_sharpen = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], dtype=np.float32)
sharpened = cv2.filter2D(image, -1, kernel_sharpen)

# ---------------- Emboss (3D effect) ----------------
kernel_emboss = np.array([[-2, -1, 0],
                          [-1, 1, 1],
                          [0, 1, 2]], dtype=np.float32)
embossed_image = cv2.filter2D(image, -1, kernel_emboss)

# ---------------- Show (optional) ----------------
# cv2.imshow('Box Blur', blurred_image); cv2.imshow('Gaussian', gaussian_blur)
# cv2.imshow('Sobel', sobel_mag); cv2.imshow('Emboss', embossed_image)
# cv2.waitKey(0); cv2.destroyAllWindows()

# Kernel cheat sheet
# Sobel X : [[-1,0,1],[-2,0,2],[-1,0,1]]     Sobel Y : [[-1,-2,-1],[0,0,0],[1,2,1]]
# Scharr X: [[-3,0,3],[-10,0,10],[-3,0,3]]
# Prewitt X: [[-1,0,1],[-1,0,1],[-1,0,1]]
