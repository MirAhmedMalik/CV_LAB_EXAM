"""
LAB 04 - 08 : Convolution Types (Standard/Full, Valid, Same, Valid with Strides)

Output size formula (square, per dimension):
    out = floor( (N + 2P - K) / S ) + 1
      N = input size, K = kernel size, P = padding, S = stride
 VALID : P = 0               -> out = N - K + 1  (smaller than input)
 SAME  : P = (K-1)/2         -> out = N          (same size)
 FULL  : P = K-1             -> out = N + K - 1  (bigger than input)
 STRIDE: skip pixels         -> out = floor((N - K)/S) + 1

Important: cv2.filter2D has NO 'strides' argument and always returns SAME size.
So for true valid / stride behavior use the manual function below (or crop).
"""
import cv2
import numpy as np

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

kernel = np.array([[1, 0, -1],
                   [2, 0, -2],
                   [1, 0, -1]], dtype=np.float32)

# ---------------------------------------------------------------
# A) Using OpenCV (lab style)
# ---------------------------------------------------------------
# Standard (same size output, default border = reflect-101)
result_standard = cv2.filter2D(image, -1, kernel)

# "Same" with zero padding
result_same_zero = cv2.filter2D(image, -1, kernel, borderType=cv2.BORDER_CONSTANT)

# "Same" with reflect padding
result_same_reflect = cv2.filter2D(image, -1, kernel, borderType=cv2.BORDER_REFLECT)

# "Valid": compute same-size, then crop the border (K//2 pixels each side)
k = kernel.shape[0]
pad = k // 2
result_valid = result_same_zero[pad:-pad, pad:-pad]

# Valid with stride 2: take every 2nd pixel of valid result
result_valid_stride2 = result_valid[::2, ::2]

# ---------------------------------------------------------------
# B) Manual convolution (any mode, any stride)
# ---------------------------------------------------------------
def conv2d(img, ker, mode='valid', stride=1, flip=False):
    """mode: 'valid' | 'same' | 'full'. flip=True gives true math convolution
    (kernel rotated 180). flip=False is cross-correlation (what CNNs / filter2D do)."""
    img = img.astype(np.float32)
    if flip:
        ker = np.flip(ker)
    kh, kw = ker.shape
    if mode == 'same':
        ph, pw = (kh - 1) // 2, (kw - 1) // 2
    elif mode == 'full':
        ph, pw = kh - 1, kw - 1
    else:
        ph, pw = 0, 0
    padded = np.pad(img, ((ph, ph), (pw, pw)), mode='constant')   # zero padding
    H, W = padded.shape
    out_h = (H - kh) // stride + 1
    out_w = (W - kw) // stride + 1
    out = np.zeros((out_h, out_w), dtype=np.float32)
    for i in range(out_h):
        for j in range(out_w):
            region = padded[i*stride:i*stride + kh, j*stride:j*stride + kw]
            out[i, j] = np.sum(region * ker)                       # dot product
    return out

# valid_out  = conv2d(image, kernel, 'valid')
# same_out   = conv2d(image, kernel, 'same')
# full_out   = conv2d(image, kernel, 'full')
# stride_out = conv2d(image, kernel, 'valid', stride=2)

# ---------------------------------------------------------------
# C) Output size calculator (use in numerical MCQs)
# ---------------------------------------------------------------
def output_size(N, K, P=0, S=1):
    return (N + 2 * P - K) // S + 1

# print(output_size(7, 3))            # valid          -> 5
# print(output_size(7, 3, P=1))       # same           -> 7
# print(output_size(7, 3, S=2))       # valid, stride2 -> 3
# print(output_size(5, 3, P=2))       # full           -> 7

# ---------------------------------------------------------------
# D) Worked tiny example (check by hand)
# ---------------------------------------------------------------
# a = np.arange(1, 17).reshape(4, 4).astype(np.float32)
# k = np.ones((3, 3), np.float32) / 9
# print(conv2d(a, k, 'valid'))     # 2x2 output
# print(conv2d(a, k, 'same'))      # 4x4 output
# print(conv2d(a, k, 'full'))      # 6x6 output
