# Computer Vision (AI-4002) - Lab 04: Feature Extraction
### MCQ Preparation Notes (read this, then use the code files in the exam)

---

## 0. Code files map (what to open for which question)

| File | Topic |
|---|---|
| `Lab04_01_HOG...py` | HOG (+ pedestrian detector) |
| `Lab04_02_LBP...py` | Local Binary Pattern |
| `Lab04_03_Color_Histogram.py` | Color histogram, compareHist, equalizeHist |
| `Lab04_04_HED...py` | Histogram of Edge Directions |
| `Lab04_05_HIG...py` | Histogram of Intensity Gradients |
| `Lab04_06_Texture_Energy_and_Contrast.py` | Texture energy / contrast |
| `Lab04_07_Filtering_Kernels.py` | Box, Gaussian, Sobel, Scharr, Prewitt, Laplacian, Emboss, Sharpen |
| `Lab04_08_Convolution_Types...py` | Valid / Same / Full / Stride + size formula |
| `Lab04_09_Edge_Detection_All_Techniques.py` | All edge detectors |
| `Lab04_10_Canny_Edge_Detector.py` | Canny (one-line + step by step) |
| `Lab04_11_Corner_Detection...py` | Harris, Shi-Tomasi, FAST, ORB |
| `Lab04_12_TASK_Material_Texture_Classification.py` | Lab task: wood / metal / fabric |

---

## 1. Feature Extraction - big picture

**Why?** Raw images are huge and high-dimensional. Feature extraction **reduces dimensions**, **keeps useful info**, **drops irrelevant details**, and makes later tasks cheaper.

| | Local Features | Global Features |
|---|---|---|
| Computed from | Small regions (keypoints, corners, patches) | Whole image |
| Examples | Corners, SIFT, ORB, LBP patches | Color histogram, texture descriptors, image moments |
| Used for | Image matching, object detection | Classification, retrieval |

**Three families of techniques**
1. Histogram-based (color, texture distributions)
2. Filter-based (Gabor, Haar wavelets: edges, textures)
3. Deep learning (CNNs learn features automatically)

**Applications:** object recognition, face recognition, gesture recognition, medical imaging, autonomous vehicles.
**Challenges:** lighting, scale, orientation, noise.

> Memory tip: **L**ocal = **L**ittle region, **G**lobal = **G**ang (whole image).

---

## 2. Histogram-based methods - comparison table

| Method | Measures | Bins | Pixels used | Typical use |
|---|---|---|---|---|
| **HOG** | Gradient direction in cells | 9 bins over 0-180 | all pixels, per 8x8 cell | Pedestrian / object detection |
| **LBP** | Local texture pattern (binary code) | P+2 = 10 (uniform, P=8) | all pixels | Texture, face recognition |
| **Color Histogram** | Color distribution | e.g. 256 / 8x8x8 | all pixels | Image retrieval |
| **HED** | Edge orientation distribution | 8 bins over 360 (45 deg each) | **only edge pixels** (Canny) | Texture, recognition, segmentation |
| **HIG** | Gradient orientation distribution | 9 bins over 0-180 | **all pixels** | Recognition, classification |
| **Texture Energy/Contrast** | Uniformity / variation | 256 | local windows 3x3/5x5 | Texture classification |

### 2.1 HOG steps
1. Convert to grayscale
2. Gradients with **Sobel** (magnitude + orientation)
3. Divide into **8x8 cells (non-overlapping)**
4. Per cell: histogram of orientations (bins e.g. 0-20, 20-40 ...)
5. Group cells into **2x2 blocks**, **normalize** (reduces lighting effect)
6. Concatenate blocks = **feature vector**

Feature length for 64x128 window = 7 x 15 blocks x 4 cells x 9 bins = **3780**.
> Memory tip: **G-C-H-B-F** = Gradient, Cells, Histogram, Block-normalize, Feature vector.

### 2.2 LBP steps
1. Grayscale  2. Choose circular neighborhood (radius R, points P)
3. Compare each neighbor with center: **neighbor >= center -> 1, else 0**
4. Join bits = LBP code  5. Histogram of codes  6. Histogram = feature vector

Worked example (center = 6): neighbors `5 2 1 / 7 _ 8 / 9 3 4` -> clockwise from top-left `5,2,1,8,4,3,9,7`
bits `0,0,0,1,0,0,1,1` = `00010011` = **19**.

| skimage `method` | Meaning |
|---|---|
| `default` | original, 2^P patterns (256) |
| `ror` | rotation invariant |
| `uniform` | rotation invariant + uniform, **P+2 bins** |
| `nri_uniform` | non-rotation-invariant uniform |
| `var` | local variance |

Uniform pattern = at most **2 transitions** (0->1 or 1->0) in the circular code.
> Memory tip: LBP = "**L**ocal **B**inary **P**attern" = compare **to the centre**, get **bits**.

### 2.3 Color histogram
Divide color space (RGB/HSV) into bins, count pixels per bin. **Ignores spatial position.**
OpenCV loads **BGR**, not RGB. Hue range in OpenCV = **0-179**.

### 2.4 HED vs HIG (very common MCQ)

| | HED | HIG |
|---|---|---|
| Needs edge detector first? | **Yes** (Canny/Sobel) | **No** (direct gradients) |
| Pixels counted | Edge pixels only | All pixels |
| Angle range in lab | 0-360, 8 bins | 0-180, 9 bins |
| Orientation by | `arctan2(gy, gx)` | `atan2(dy, dx)` |

Formulas: **Magnitude G = sqrt(dx^2 + dy^2)**, **Orientation = atan2(dy, dx)**.

### 2.5 Texture energy & contrast

| | Energy | Contrast |
|---|---|---|
| Formula | E = sum(pixel^2) in window | C = sqrt(Var(pixels)) = std dev |
| Measures | Uniformity / smoothness | Variation of intensity |
| High value means | More complex, less uniform texture | Greater variation in texture |
| Window | 3x3 or 5x5 | 3x3 or 5x5 |

Other texture tools: **GLCM** (contrast, homogeneity, energy, correlation), **Gabor filters**, **LBP**.

---

## 3. Filtering and Convolution

**Filter / kernel** = small matrix of weights. **Convolution** = slide kernel over image, multiply element-wise with region, **sum** (dot product), do for every pixel.

- Blur kernels: **sum = 1** (keeps brightness). Edge kernels: **sum = 0**.
- OpenCV `filter2D` actually does **correlation** (no kernel flip). Result is the same for symmetric kernels.

| Filter | Purpose | Kernel idea |
|---|---|---|
| Box blur | Smooth, reduce noise | all ones / 9 |
| Gaussian blur | Smoother than box, less noise | bell-shaped weights |
| Median | Removes salt-and-pepper noise | non-linear |
| Sobel | Edges (gradient) | `[-1 0 1; -2 0 2; -1 0 1]` |
| Scharr | More accurate Sobel | `[-3 0 3; -10 0 10; -3 0 3]` |
| Prewitt | Edges, simple | `[-1 0 1; -1 0 1; -1 0 1]` |
| Laplacian | 2nd derivative edges | `[0 1 0; 1 -4 1; 0 1 0]` |
| Sharpen | Enhance detail | `[0 -1 0; -1 5 -1; 0 -1 0]` |
| Emboss | 3D effect | `[-2 -1 0; -1 1 1; 0 1 2]` |

### 3.1 Convolution types

| Type | Padding | Output size | Notes |
|---|---|---|---|
| **Standard / Full** (lab: "standard") | P = K-1 (full) | N + K - 1 | Lab says "most common", centers kernel on every pixel |
| **Valid** (no padding) | 0 | N - K + 1 | Only where kernel **fully overlaps**; output **smaller** |
| **Same** (zero padding) | (K-1)/2 | N | Output **same size** as input; prevents border loss |
| **Valid with stride** | 0 | floor((N-K)/S) + 1 | **Skips** pixels, output smaller |

**General formula:** `out = floor((N + 2P - K) / S) + 1`

Worked: N=7, K=3 -> valid 5 | same (P=1) 7 | valid stride 2 -> floor(4/2)+1 = **3**.
> Memory tip: **V**alid = **V**anishes border (smaller). **S**ame = **S**ame size.

---

## 4. Edge detection

**Edge** = boundary where color / intensity / texture changes sharply. Used in detection, segmentation, feature extraction. Reduces data but keeps structure.

| Technique | Derivative | Key point |
|---|---|---|
| Sobel | 1st | Gradient, 3x3, horizontal and vertical, simple |
| Prewitt | 1st | 3x3, simpler weights than Sobel |
| Scharr | 1st | Better rotational accuracy than Sobel |
| Roberts | 1st | 2x2, very fast, noise sensitive |
| Laplacian | 2nd | Edges at **zero-crossings**, very noise sensitive |
| LoG | 2nd | **Gaussian smoothing + Laplacian**, zero-crossings |
| Marr-Hildreth | 2nd | Same idea as LoG: smooth then zero-crossing |
| Canny | 1st + extras | Multi-stage, best accuracy and noise handling |
| CNN-based (HED net) | learned | Learns complex edge patterns |

**Gradient-based:** edge where gradient **magnitude is high**.
**Second-derivative:** edge at **zero-crossing**.

### 4.1 Canny (by John F. Canny, 1986) - 4 steps
1. **Gaussian smoothing** - reduce noise (bigger sigma = smoother, loses fine detail)
2. **Gradient calculation** - Sobel kernels (3x3), magnitude and direction
3. **Non-Maximum Suppression** - keep only local maxima along gradient direction -> **thin edges**
4. **Hysteresis (edge tracking)** - two thresholds:
   - magnitude > **T_high** -> strong edge (definitely edge)
   - between **T_low** and **T_high** -> weak edge, kept **only if connected to a strong edge**
   - < **T_low** -> rejected

Parameters: Gaussian kernel size/sigma, T_high, T_low. Recommended ratio **T_high : T_low about 2:1 or 3:1**.
OpenCV: `cv2.Canny(img, threshold1=T_low, threshold2=T_high)`.
Low thresholds -> more edges + noise. High thresholds -> fewer edges, may miss real ones.
> Memory tip: Canny = **G**ood **G**uys **N**ever **H**esitate (Gauss, Gradient, NMS, Hysteresis).

---

## 5. Corner detection

| Region | Change in intensity |
|---|---|
| Flat | none in any direction |
| Edge | strong in **one** direction |
| Corner | strong in **two** directions |

| Method | Idea |
|---|---|
| **Harris** | `R = det(M) - k*trace(M)^2`, k = 0.04-0.06. R large positive = corner, R negative = edge, R small = flat |
| **Shi-Tomasi** | Corner if `min(lambda1, lambda2)` > threshold. Improved Harris. `cv2.goodFeaturesToTrack` |
| **FAST** | Compares circle of 16 pixels to center. Very fast, real-time |
| **ORB** | FAST keypoints + BRIEF descriptor. Free, fast alternative to SIFT/SURF |

Corners are **local features** (good for matching and tracking).

---

## 6. Lab task answer - material classification (wood / metal / fabric)
- **LBP**: micro-texture, robust to lighting, fast; weak with noise, ignores color, only local.
- **Energy + Contrast**: separates smooth (polished metal) from rough (wood, fabric); weak with similar contrast, brightness dependent.
- **GLCM**: spatial relationship of pixel pairs. **Gabor**: directional texture (wood grain).
- Pipeline: grayscale -> resize -> features -> scale -> SVM -> evaluate. Code: `Lab04_12_...py`.

---

## 7. Mistakes in the lab handout (watch for these in tricky MCQs)
1. `cv2.filter2D` has **no `strides` parameter**; it always returns same-size output. Real valid/stride need manual code (file 08).
2. `image ** 2` on `uint8` **overflows**. Convert to `float32` first (file 06).
3. `arctan2` gives -180 to 180. Use `% 360` or `% 180` before binning (files 04, 05).
4. `getGaussianKernel` returns a **1D** kernel. Make 2D with `k @ k.T`.
5. "Valid" via `BORDER_CONSTANT` and "Same" via `BORDER_REFLECT` only change the **border fill**, not the output size.

---

## 8. Quick-fire MCQs (answers at the end of each)

**Q1.** Feature extraction mainly does what?
a) Increases image size b) Reduces dimensionality and keeps relevant info c) Adds noise d) Converts to color
**Answer: b**

**Q2.** Which is a GLOBAL feature?
a) Corner b) Keypoint c) Color histogram d) Small patch
**Answer: c**

**Q3.** HOG is mainly used for?
a) Color matching b) Pedestrian / object detection c) Blurring d) Compression
**Answer: b**

**Q4.** Default HOG cell size in the lab?
a) 4x4 b) 8x8 c) 16x16 d) 32x32
**Answer: b**

**Q5.** Purpose of block normalization in HOG?
a) Reduce lighting variation effects b) Add noise c) Resize d) Convert color
**Answer: a**

**Q6.** Which operator is typically used for gradients in HOG?
a) Laplacian b) Sobel c) Median d) Canny
**Answer: b**

**Q7.** In LBP, a neighbor is set to 1 when?
a) neighbor < center b) neighbor >= center c) neighbor == 0 d) neighbor > 255
**Answer: b**

**Q8.** Uniform LBP with 8 points gives how many bins?
a) 8 b) 9 c) 10 d) 256
**Answer: c (P+2)**

**Q9.** LBP is best for?
a) Texture classification b) Edge thinning c) Color shift d) Blurring
**Answer: a**

**Q10.** Which histogram method ignores spatial position?
a) HOG b) Color histogram c) Canny d) Harris
**Answer: b**

**Q11.** HED computes orientation histogram using?
a) All pixels b) Only edge pixels c) Only corners d) Only color pixels
**Answer: b**

**Q12.** HIG formula for magnitude?
a) dx + dy b) sqrt(dx^2 + dy^2) c) dx * dy d) atan2(dy, dx)
**Answer: b**

**Q13.** Texture contrast is computed as?
a) Sum of squares b) Standard deviation of pixels c) Mean d) Median
**Answer: b**

**Q14.** Higher texture energy (lab definition) indicates?
a) Simple uniform texture b) More complex, less uniform texture c) No texture d) Blur
**Answer: b**

**Q15.** Sum of a blur kernel's weights is normally?
a) 0 b) 1 c) -1 d) 255
**Answer: b**

**Q16.** Which filter best removes salt-and-pepper noise?
a) Box b) Gaussian c) Median d) Sobel
**Answer: c**

**Q17.** Convolution is computed as?
a) Dot product of kernel and image region b) Sorting c) Thresholding d) Histogram
**Answer: a**

**Q18.** Valid convolution output compared to input?
a) Larger b) Same c) Smaller d) Binary
**Answer: c**

**Q19.** Same convolution needs?
a) Zero padding b) No padding c) Stride 3 d) Larger kernel
**Answer: a**

**Q20.** Input 10x10, kernel 3x3, no padding, stride 1. Output size?
a) 10 b) 9 c) 8 d) 7
**Answer: c (10 - 3 + 1 = 8)**

**Q21.** Input 9x9, kernel 3x3, no padding, stride 2. Output size?
a) 3 b) 4 c) 5 d) 7
**Answer: b (floor((9-3)/2) + 1 = 4)**

**Q22.** Input 5x5, kernel 3x3, padding 1, stride 1. Output size?
a) 3 b) 5 c) 7 d) 9
**Answer: b**

**Q23.** Edges in gradient-based methods occur where?
a) Gradient magnitude is high b) Gradient is zero c) Image is blurred d) Pixels are black
**Answer: a**

**Q24.** Laplacian-based edges are found at?
a) Maxima b) Zero-crossings c) Minima only d) Corners
**Answer: b**

**Q25.** LoG combines?
a) Sobel + Canny b) Gaussian smoothing + Laplacian c) Median + Box d) Harris + FAST
**Answer: b**

**Q26.** Which is NOT a step of Canny?
a) Gaussian smoothing b) Non-max suppression c) Hysteresis d) Histogram equalization
**Answer: d**

**Q27.** What does non-maximum suppression do?
a) Blurs edges b) Thins edges c) Adds noise d) Colors edges
**Answer: b**

**Q28.** In hysteresis, weak edges are kept when?
a) They are above T_high b) They are connected to strong edges c) They are below T_low d) Always
**Answer: b**

**Q29.** Larger sigma in Gaussian smoothing results in?
a) Sharper image, more detail b) Smoother image, may lose fine detail c) No change d) Binary image
**Answer: b**

**Q30.** Canny was developed by?
a) Sobel b) Harris c) John F. Canny, 1986 d) Prewitt
**Answer: c**

**Q31.** Which is more accurate than Sobel for 3x3 gradient?
a) Prewitt b) Scharr c) Roberts d) Box
**Answer: b**

**Q32.** Corner means intensity changes strongly in?
a) No direction b) One direction c) Two directions d) Random
**Answer: c**

**Q33.** Harris response R for a corner is?
a) Large positive b) Large negative c) Near zero d) Exactly 1
**Answer: a**

**Q34.** Which corner detector is built for real-time speed?
a) Harris b) FAST c) Canny d) HOG
**Answer: b**

**Q35.** OpenCV reads color images in which channel order?
a) RGB b) BGR c) HSV d) GRAY
**Answer: b**

---

## 9. Last-minute memory sheet

- **HOG** = Sobel + 8x8 cells + 9 bins + 2x2 block norm. Detection.
- **LBP** = compare to center, >= gives 1. Texture. Uniform = P+2 bins.
- **HED** = edge pixels only, 8 bins x 45 deg. **HIG** = all pixels, 9 bins.
- **Energy** = sum of squares. **Contrast** = std dev.
- **Valid** smaller, **Same** equal, **Full** larger. `out = (N+2P-K)/S + 1`.
- **Sobel/Prewitt/Scharr** = 1st derivative. **Laplacian/LoG** = 2nd derivative (zero-crossing).
- **Canny** = Gauss, Gradient, NMS, Hysteresis (T_high strong, T_low reject).
- **Corner** = change in two directions. Harris, Shi-Tomasi, FAST, ORB.
