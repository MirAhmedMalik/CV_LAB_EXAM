"""
LAB 04 - 09 : Edge Detection Techniques
Edge = sudden change in intensity/color/texture. Reduces data, keeps structure.
Types:
  1st derivative (gradient): Sobel, Prewitt, Scharr, Roberts  -> edge where magnitude is HIGH
  2nd derivative: Laplacian, LoG / Marr-Hildreth              -> edge where ZERO-CROSSING
  Multi-stage: Canny
  Learning-based: CNN (HED network)
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

# ---------------------------------------------------------------
# 1) Sobel (lab version)
# ---------------------------------------------------------------
gradient_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)    # x-direction (vertical edges)
gradient_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)    # y-direction (horizontal edges)
gradient_magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
gradient_direction = np.arctan2(gradient_y, gradient_x)

threshold = 100
edges_sobel = (gradient_magnitude > threshold).astype(np.uint8) * 255

# ---------------------------------------------------------------
# 2) Scharr
# ---------------------------------------------------------------
scharr_x = cv2.Scharr(image, cv2.CV_64F, 1, 0)
scharr_y = cv2.Scharr(image, cv2.CV_64F, 0, 1)
edges_scharr = np.sqrt(scharr_x ** 2 + scharr_y ** 2)

# ---------------------------------------------------------------
# 3) Prewitt
# ---------------------------------------------------------------
kx = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=np.float32)
ky = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]], dtype=np.float32)
px = cv2.filter2D(image, cv2.CV_64F, kx)
py = cv2.filter2D(image, cv2.CV_64F, ky)
edges_prewitt = np.sqrt(px ** 2 + py ** 2)

# ---------------------------------------------------------------
# 4) Roberts (2x2)
# ---------------------------------------------------------------
rx = np.array([[1, 0], [0, -1]], dtype=np.float32)
ry = np.array([[0, 1], [-1, 0]], dtype=np.float32)
edges_roberts = np.sqrt(cv2.filter2D(image, cv2.CV_64F, rx) ** 2 +
                        cv2.filter2D(image, cv2.CV_64F, ry) ** 2)

# ---------------------------------------------------------------
# 5) Laplacian (2nd derivative, noise sensitive)
# ---------------------------------------------------------------
edges_laplacian = cv2.convertScaleAbs(cv2.Laplacian(image, cv2.CV_64F, ksize=3))

# ---------------------------------------------------------------
# 6) LoG / Marr-Hildreth : Gaussian smoothing + Laplacian + zero-crossings
# ---------------------------------------------------------------
def marr_hildreth(gray, ksize=5, sigma=1.4, thresh=0.0):
    blur = cv2.GaussianBlur(gray, (ksize, ksize), sigma)
    log = cv2.Laplacian(blur, cv2.CV_64F)
    zc = np.zeros_like(log, dtype=np.uint8)
    # zero-crossing: sign change between a pixel and its right/bottom neighbor
    for dy, dx in [(0, 1), (1, 0), (1, 1), (1, -1)]:
        shifted = np.roll(np.roll(log, -dy, axis=0), -dx, axis=1)
        crossing = (np.sign(log) != np.sign(shifted)) & (np.abs(log - shifted) > thresh)
        zc[crossing] = 255
    return zc

edges_log = marr_hildreth(image)

# ---------------------------------------------------------------
# 7) Canny (best all-round; see file 10 for the steps)
# ---------------------------------------------------------------
edges_canny = cv2.Canny(image, 100, 200)

# ---------------------------------------------------------------
# Show all
# ---------------------------------------------------------------
titles = ['Original', 'Sobel', 'Scharr', 'Prewitt', 'Roberts', 'Laplacian', 'LoG (Marr-Hildreth)', 'Canny']
imgs = [image, edges_sobel, edges_scharr, edges_prewitt, edges_roberts, edges_laplacian, edges_log, edges_canny]
plt.figure(figsize=(16, 8))
for i, (t, im) in enumerate(zip(titles, imgs)):
    plt.subplot(2, 4, i + 1); plt.imshow(im, cmap='gray'); plt.title(t); plt.axis('off')
plt.tight_layout(); plt.show()

# Lab-style window display
# cv2.imshow('Original Image', image); cv2.imshow('Detected Edges', edges_sobel)
# cv2.waitKey(0); cv2.destroyAllWindows()
