"""
LAB 04 - 02 : LBP (Local Binary Pattern)
Use for: TEXTURE classification, face recognition.
Rule: neighbor >= center -> 1, else 0. Read bits -> binary number -> histogram.
'uniform' method with P points gives P + 2 bins (P=8 -> 10 bins).
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import feature

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

# ---------------------------------------------------------------
# A) LBP with scikit-image (lab version)
# ---------------------------------------------------------------
radius = 1                 # radius of circular neighborhood
n_points = 8 * radius      # number of neighbors

lbp_image = feature.local_binary_pattern(image, n_points, radius, method='uniform')

hist, _ = np.histogram(lbp_image.ravel(), bins=np.arange(0, n_points + 3), range=(0, n_points + 2))
hist = hist.astype("float")
hist /= (hist.sum() + 1e-6)          # normalize

plt.figure(figsize=(12, 6))
plt.subplot(121); plt.imshow(lbp_image, cmap='gray'); plt.title('LBP Image')
plt.subplot(122); plt.bar(range(0, n_points + 2), hist)
plt.title('LBP Histogram'); plt.xlabel('LBP Patterns'); plt.ylabel('Frequency')
plt.show()

print("LBP Feature Vector:", hist)

# method options (MCQ):
# 'default' : original LBP, 2^P patterns (256 for P=8)
# 'ror'     : rotation invariant
# 'uniform' : rotation invariant + uniform (P+2 bins)
# 'nri_uniform' : non-rotation-invariant uniform (P*(P-1)+3 bins)
# 'var'     : variance of local image texture

# ---------------------------------------------------------------
# B) Manual 3x3 LBP (shows the idea; good for worked examples)
# ---------------------------------------------------------------
def lbp_3x3(gray):
    g = gray.astype(np.int32)
    h, w = g.shape
    out = np.zeros((h - 2, w - 2), dtype=np.uint8)
    center = g[1:-1, 1:-1]
    # clockwise from top-left; weights 128,64,32,16,8,4,2,1
    offsets = [(-1, -1), (-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1)]
    for k, (dy, dx) in enumerate(offsets):
        neighbor = g[1 + dy:h - 1 + dy, 1 + dx:w - 1 + dx]
        out |= ((neighbor >= center).astype(np.uint8) << (7 - k))
    return out

# lbp_manual = lbp_3x3(image)
# hist_manual, _ = np.histogram(lbp_manual.ravel(), bins=256, range=(0, 256))

# ---------------------------------------------------------------
# C) Region-wise LBP histogram (better features: grid of cells)
# ---------------------------------------------------------------
def lbp_grid_histogram(gray, grid=(4, 4), P=8, R=1):
    lbp = feature.local_binary_pattern(gray, P, R, method='uniform')
    h, w = lbp.shape
    gh, gw = h // grid[0], w // grid[1]
    feats = []
    for i in range(grid[0]):
        for j in range(grid[1]):
            cell = lbp[i*gh:(i+1)*gh, j*gw:(j+1)*gw]
            hst, _ = np.histogram(cell.ravel(), bins=np.arange(0, P + 3), range=(0, P + 2))
            feats.extend(hst / (hst.sum() + 1e-6))
    return np.array(feats)
