"""
LAB 04 - 04 : HED (Histogram of Edge Directions)
Use for: texture analysis, object recognition, segmentation.
Pipeline: grayscale -> (Gaussian blur) -> Canny edge map -> gradient angle
          -> bin angles (8 bins of 45 deg over 360) -> histogram = feature vector.
NOTE: HED counts ONLY edge pixels (edge map > 0).
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

# 1) Preprocess (optional smoothing)
image_smoothed = cv2.GaussianBlur(image, (5, 5), 0)

# 2) Edge detection
edges = cv2.Canny(image_smoothed, threshold1=30, threshold2=70)

# 3) Gradient direction
gradient_x = cv2.Sobel(image_smoothed, cv2.CV_64F, 1, 0, ksize=3)
gradient_y = cv2.Sobel(image_smoothed, cv2.CV_64F, 0, 1, ksize=3)
gradient_magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
gradient_orientation = np.degrees(np.arctan2(gradient_y, gradient_x)) % 360   # map -180..180 to 0..360

# 4) Keep angles only where an edge exists
edge_angles = gradient_orientation[edges > 0]

# 5) Histogram: 8 bins of 45 degrees
hist, bin_edges = np.histogram(edge_angles, bins=8, range=(0, 360))
hist_norm = hist / (hist.sum() + 1e-6)          # normalized feature vector

plt.figure(figsize=(12, 6))
plt.subplot(121); plt.imshow(edges, cmap='gray'); plt.title('Edge Map')
plt.subplot(122); plt.bar(bin_edges[:-1], hist, width=45, align='edge')
plt.title('Histogram of Edge Directions'); plt.xlabel('Edge Direction (degrees)'); plt.ylabel('Frequency')
plt.xticks(range(0, 360, 45))
plt.show()

print("HED Feature Vector (counts):", hist)
print("HED Feature Vector (normalized):", hist_norm)
