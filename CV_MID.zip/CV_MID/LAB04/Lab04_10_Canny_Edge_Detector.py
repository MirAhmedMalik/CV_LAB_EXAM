"""
LAB 04 - 10 : Canny Edge Detector (John F. Canny, 1986)
4 steps (memory: G-G-N-H = "Get Great Neat Hairlines"):
  1. Gaussian smoothing          -> remove noise
  2. Gradient calculation        -> Sobel x,y -> magnitude + direction
  3. Non-Maximum Suppression     -> thin edges to 1 pixel
  4. Hysteresis thresholding     -> > T_high strong, < T_low rejected,
                                    in-between kept ONLY if connected to strong
Parameters: Gaussian kernel size / sigma, T_low, T_high (ratio about 1:2 or 1:3).
Larger sigma = smoother but loses fine detail.
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

# ---------------------------------------------------------------
# A) One-line Canny (lab version)
# ---------------------------------------------------------------
edges = cv2.Canny(image, threshold1=100, threshold2=200)   # threshold1=T_low, threshold2=T_high
cv2.imshow('Canny Edges', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()

# ---------------------------------------------------------------
# B) Automatic thresholds (when you do not know what to pick)
# ---------------------------------------------------------------
def auto_canny(gray, sigma=0.33):
    v = np.median(gray)
    low = int(max(0, (1.0 - sigma) * v))
    high = int(min(255, (1.0 + sigma) * v))
    return cv2.Canny(gray, low, high)

edges_auto = auto_canny(cv2.GaussianBlur(image, (5, 5), 0))

# ---------------------------------------------------------------
# C) Canny step by step (to show every stage)
# ---------------------------------------------------------------
def canny_steps(gray, low=50, high=150, ksize=5, sigma=1.4):
    # Step 1: Gaussian smoothing
    smooth = cv2.GaussianBlur(gray, (ksize, ksize), sigma).astype(np.float32)

    # Step 2: Gradient (Sobel) -> magnitude, direction
    gx = cv2.Sobel(smooth, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(smooth, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.hypot(gx, gy)
    ang = (np.degrees(np.arctan2(gy, gx)) + 180) % 180      # 0..180

    # Step 3: Non-Maximum Suppression (compare with 2 neighbors along gradient direction)
    H, W = mag.shape
    nms = np.zeros_like(mag)
    for i in range(1, H - 1):
        for j in range(1, W - 1):
            a = ang[i, j]
            if (0 <= a < 22.5) or (157.5 <= a <= 180):       # horizontal gradient
                n1, n2 = mag[i, j - 1], mag[i, j + 1]
            elif 22.5 <= a < 67.5:                           # 45 deg
                n1, n2 = mag[i - 1, j + 1], mag[i + 1, j - 1]
            elif 67.5 <= a < 112.5:                          # vertical gradient
                n1, n2 = mag[i - 1, j], mag[i + 1, j]
            else:                                            # 135 deg
                n1, n2 = mag[i - 1, j - 1], mag[i + 1, j + 1]
            if mag[i, j] >= n1 and mag[i, j] >= n2:
                nms[i, j] = mag[i, j]

    # Step 4: Hysteresis
    strong = nms >= high
    weak = (nms >= low) & (nms < high)
    labels, n = ndimage.label(strong | weak, structure=np.ones((3, 3)))   # 8-connectivity
    keep = np.unique(labels[strong])                         # components containing a strong pixel
    keep = keep[keep != 0]
    final = np.isin(labels, keep).astype(np.uint8) * 255
    return smooth, mag, nms, final

# smooth, mag, nms, final = canny_steps(image)

# ---------------------------------------------------------------
# D) Effect of thresholds (compare)
# ---------------------------------------------------------------
plt.figure(figsize=(12, 4))
for k, (lo, hi) in enumerate([(30, 70), (100, 200), (150, 250)]):
    plt.subplot(1, 3, k + 1)
    plt.imshow(cv2.Canny(image, lo, hi), cmap='gray')
    plt.title(f'low={lo}, high={hi}'); plt.axis('off')
plt.show()
# low thresholds  -> many edges + noise
# high thresholds -> few edges, may miss real ones
