"""
LAB 04 - 05 : HIG (Histogram of Intensity Gradients)
Use for: object recognition, texture analysis, image classification.
Pipeline: grayscale -> Sobel dx, dy -> magnitude + orientation
          -> histogram of orientations (9 bins, 0-180) -> normalize.
Formulas:  G = sqrt(dx^2 + dy^2)      theta = atan2(dy, dx)
Difference vs HED: HIG uses ALL pixels (no edge map); HED uses edge pixels only.
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE)

# Gradients
dx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
dy = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)

# Magnitude and orientation (degrees, unsigned 0-180)
magnitude = np.sqrt(dx ** 2 + dy ** 2)
orientation = np.degrees(np.arctan2(dy, dx)) % 180

# A) Lab version: simple count histogram
histogram, bins = np.histogram(orientation, bins=9, range=(0, 180))
histogram = histogram / histogram.sum()                 # normalize (scale-invariant)

# B) Better version: weight each pixel's vote by its gradient magnitude
histogram_weighted, _ = np.histogram(orientation, bins=9, range=(0, 180), weights=magnitude)
histogram_weighted = histogram_weighted / (histogram_weighted.sum() + 1e-6)

plt.bar(bins[:-1], histogram, width=20, align='edge')
plt.title("Histogram of Intensity Gradients (HIG)")
plt.xlabel("Gradient Orientation (degrees)")
plt.ylabel("Frequency")
plt.show()

feature_vector = histogram          # use as feature vector for your application
print("HIG Feature Vector:", feature_vector)
