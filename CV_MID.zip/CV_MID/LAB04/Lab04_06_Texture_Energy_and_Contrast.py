"""
LAB 04 - 06 : Texture Energy and Contrast Histograms
Texture Energy  E = sum(pixel values^2) in a local window  -> uniformity/smoothness
Texture Contrast C = sqrt(Var(pixel values)) in a window   -> variation (std dev)
Window sizes: 3x3 or 5x5.

NOTE: convert image to float32 first. uint8 ** 2 overflows (wraps around at 255)!
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt

IMG_PATH = 'image.jpg'   # <-- change this
image = cv2.imread(IMG_PATH, cv2.IMREAD_GRAYSCALE).astype(np.float32)

neighborhood_size = 3
kernel = np.ones((neighborhood_size, neighborhood_size), np.float32)
n = neighborhood_size * neighborhood_size

# ---------------------------------------------------------------
# Texture ENERGY = local sum of squares
# ---------------------------------------------------------------
energy = cv2.filter2D(image ** 2, -1, kernel)

# ---------------------------------------------------------------
# Texture CONTRAST = local standard deviation
# Var = E[x^2] - (E[x])^2
# ---------------------------------------------------------------
mean = cv2.filter2D(image, -1, kernel) / n
mean_sq = cv2.filter2D(image ** 2, -1, kernel) / n
contrast = np.sqrt(np.maximum(mean_sq - mean ** 2, 0))

# ---------------------------------------------------------------
# Histograms (feature vectors)
# ---------------------------------------------------------------
energy_histogram, energy_bins = np.histogram(energy, bins=256, range=(0, energy.max()))
contrast_histogram, contrast_bins = np.histogram(contrast, bins=256, range=(0, contrast.max()))

energy_histogram = energy_histogram / energy_histogram.sum()
contrast_histogram = contrast_histogram / contrast_histogram.sum()

plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(energy_bins[:-1], energy_histogram, color='b')
plt.title("Texture Energy Histogram"); plt.xlabel("Energy"); plt.ylabel("Frequency")
plt.subplot(1, 2, 2)
plt.plot(contrast_bins[:-1], contrast_histogram, color='r')
plt.title("Texture Contrast Histogram"); plt.xlabel("Contrast"); plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# Combined feature vector for a classifier
feature_vector = np.concatenate([energy_histogram, contrast_histogram])

# Quick summary features (4 numbers per image)
summary = [energy.mean(), energy.std(), contrast.mean(), contrast.std()]
