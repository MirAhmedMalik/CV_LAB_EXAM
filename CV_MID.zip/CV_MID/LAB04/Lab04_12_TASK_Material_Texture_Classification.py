"""
LAB 04 - 12 : TASK - Texture Analysis for Material Classification (wood / metal / fabric)

QUESTION: Describe at least two texture feature extraction techniques. Explain how each works,
what textures suit it, and discuss advantages and limitations.

ANSWER SUMMARY (write this in the exam)
---------------------------------------
Technique 1 - LBP (Local Binary Pattern)
  How: compare each pixel with its circular neighbors (>= center -> 1 else 0), form a binary
       code, build histogram of codes over image = feature vector.
  Good for: fine micro-textures: fabric weave, wood grain, rough/brushed surfaces.
  Advantages: simple, fast, robust to lighting (monotonic gray change), rotation-invariant
              with 'uniform' method, compact histogram.
  Limitations: sensitive to noise, ignores color, captures only very local pattern,
               fixed radius misses large-scale texture, histogram loses spatial layout.

Technique 2 - Texture Energy and Contrast (and/or GLCM)
  How: in a 3x3 / 5x5 window, energy = sum of squared pixels, contrast = std deviation;
       histograms of both are the features.
  Good for: telling smooth (polished metal: low contrast) from rough/patterned
            (wood, fabric: high contrast).
  Advantages: easy to compute, interpretable, good smooth-vs-rough separation.
  Limitations: depends on brightness and window size, no direction information, weak
               for similar-contrast materials.

Technique 3 - GLCM (Gray Level Co-occurrence Matrix) properties: contrast, homogeneity,
              energy, correlation, dissimilarity. Captures spatial relation of pixel pairs.
Technique 4 - Gabor filters: orientation + frequency; good for directional textures (wood grain).

Dataset layout expected:  dataset/wood/*.jpg   dataset/metal/*.jpg   dataset/fabric/*.jpg
"""
import os
import glob
import cv2
import numpy as np
from skimage.feature import local_binary_pattern, graycomatrix, graycoprops
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score

DATASET_DIR = 'dataset'          # <-- change this
IMG_SIZE = (128, 128)
P, R = 8, 1

# ---------------- Feature 1: LBP histogram ----------------
def lbp_features(gray):
    lbp = local_binary_pattern(gray, P, R, method='uniform')
    hist, _ = np.histogram(lbp.ravel(), bins=np.arange(0, P + 3), range=(0, P + 2))
    return hist / (hist.sum() + 1e-6)

# ---------------- Feature 2: Energy + Contrast ----------------
def energy_contrast_features(gray, k=3):
    g = gray.astype(np.float32)
    ker = np.ones((k, k), np.float32)
    n = k * k
    energy = cv2.filter2D(g ** 2, -1, ker)
    mean = cv2.filter2D(g, -1, ker) / n
    contrast = np.sqrt(np.maximum(cv2.filter2D(g ** 2, -1, ker) / n - mean ** 2, 0))
    return np.array([energy.mean(), energy.std(), contrast.mean(), contrast.std()])

# ---------------- Feature 3: GLCM properties ----------------
def glcm_features(gray):
    q = (gray // 32).astype(np.uint8)                     # 8 gray levels
    glcm = graycomatrix(q, distances=[1], angles=[0, np.pi/4, np.pi/2, 3*np.pi/4],
                        levels=8, symmetric=True, normed=True)
    props = ['contrast', 'homogeneity', 'energy', 'correlation', 'dissimilarity']
    return np.concatenate([graycoprops(glcm, p).ravel() for p in props])

# ---------------- Feature 4: Gabor responses ----------------
def gabor_features(gray):
    feats = []
    for theta in np.arange(0, np.pi, np.pi / 4):          # 4 orientations
        for lam in (4, 8):                                # 2 wavelengths
            kern = cv2.getGaborKernel((15, 15), 4.0, theta, lam, 0.5, 0, ktype=cv2.CV_32F)
            resp = cv2.filter2D(gray, cv2.CV_32F, kern)
            feats += [resp.mean(), resp.std()]
    return np.array(feats)

def extract_all(gray):
    return np.concatenate([lbp_features(gray),
                           energy_contrast_features(gray),
                           glcm_features(gray),
                           gabor_features(gray)])

# ---------------- Load data, train, evaluate ----------------
def load_dataset(root):
    X, y = [], []
    classes = sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)))
    for label in classes:
        for path in glob.glob(os.path.join(root, label, '*')):
            img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            img = cv2.resize(img, IMG_SIZE)
            X.append(extract_all(img))
            y.append(label)
    return np.array(X), np.array(y)

if __name__ == '__main__':
    X, y = load_dataset(DATASET_DIR)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)

    # Scale features (SVM needs it because features have different ranges)
    mu, sd = X_train.mean(0), X_train.std(0) + 1e-6
    clf = SVC(kernel='rbf', C=10, gamma='scale')
    clf.fit((X_train - mu) / sd, y_train)
    pred = clf.predict((X_test - mu) / sd)

    print("Accuracy:", accuracy_score(y_test, pred))
    print(classification_report(y_test, pred))
