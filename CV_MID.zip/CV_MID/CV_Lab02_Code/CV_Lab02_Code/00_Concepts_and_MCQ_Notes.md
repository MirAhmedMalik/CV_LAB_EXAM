# CV Lab 02: Point Transformations (Log, Gamma, Piecewise, Histogram)

## PART 1: CONCEPTS (simple English)

### What is a point transformation?
Each output pixel depends ONLY on the same input pixel. No neighbours used.
**s = T(r)**  (r = input pixel, s = output pixel, range 0-255 for 8-bit, L = 256 levels)
- Different from filtering (uses neighbours, e.g. blur). Point ops change brightness/contrast only, not shape.
- Often done with a **LUT** (lookup table of 256 values): fast, same result.

### 1. Negative
`s = (L-1) - r = 255 - r`. Good for white details on dark background.

### 2. Log transform
`s = c * log(1 + r)`,  `c = 255 / log(1 + max)`
- **Expands dark values, compresses bright values.**
- Use: very dark image, faint details (X-ray ribs, dark heart chambers).
- Why `1 + r`? log(0) is undefined, so add 1.
- Inverse log does the opposite (expands bright).

### 3. Power-law (Gamma)
`s = c * r^gamma` (normalize r to 0-1 first): `s = 255 * (r/255)^gamma`
| gamma | effect |
|---|---|
| < 1 (0.4) | brighter, expands dark (like log) |
| = 1 | no change (identity) |
| > 1 (2.2) | darker, expands bright, suppresses white noise |
- Gamma < 1 = "fractional" power-law. Used for display devices (gamma correction), washed-out (> 1) or dark (< 1) images.
- More flexible than log: you choose gamma.

### 4. Piecewise-linear (contrast stretching)
Joins points (r1,s1), (r2,s2) with straight lines (3 segments).
- r1<r2, s1<s2 -> keeps order of intensities (no inversion).
- r1=s1 and r2=s2 -> identity (no change).
- r1=r2, s1=0, s2=255 -> **thresholding** (binary image).
- Pushing r1 down, r2 up in range [min,max] -> full stretch (`min-max normalization`).
- Other piecewise ops: **intensity-level slicing** (highlight a range), **bit-plane slicing**.
- Advantage: shape is fully user-controlled. Disadvantage: needs more user input.

### 5. Histogram
Histogram = count of pixels at each intensity (x: 0-255, y: count).
- Dark image: bars on LEFT. Bright image: bars on RIGHT. Low contrast: narrow bars in middle. Good contrast: spread over full range.
- Normalized histogram `p(r_k) = n_k / N` (sum = 1, like probability).

### 6. Histogram Equalization (HE)
Makes histogram roughly **flat/uniform** to increase global contrast.
Steps:
1. Histogram `n_k`  2. PDF `p = n_k/N`  3. CDF = running sum of p
4. `s_k = round((L-1) * CDF(r_k))`  5. Replace each pixel r_k by s_k.
- Equalized histogram is *approximately* flat, never perfectly (discrete levels).
- Applying HE twice = same as once (idempotent).
- Problem: amplifies noise, can look unnatural. Fix: **CLAHE** (local tiles + `clipLimit`).
- HE works on gray image. For colour: equalize only the **V channel (HSV)** or **Y channel (YCrCb)**, not each of B,G,R (colours shift).
- **Histogram matching/specification** = make histogram match a chosen shape, not flat.

### 7. Other lab ideas
- **Colour map (JET):** gray -> colour. Eye separates colours better than gray levels. Blue = low, red = high.
- **Colour balance (gray-world):** scale B,G,R so channel means are equal -> removes colour cast.
- **Thresholding:** `pixel > T -> 255 else 0`. Otsu picks T automatically.
- **cv2.addWeighted(a, alpha, b, beta, gamma)** = `alpha*a + beta*b + gamma`. Images need same size and same channels. Usually alpha+beta = 1.

---

## PART 2: MCQ IMPORTANT POINTS (memorize)

| Topic | Fact |
|---|---|
| Point op | Output pixel depends only on that input pixel |
| Log | Expands dark, compresses bright |
| Gamma < 1 | Brightens image (expands dark) |
| Gamma > 1 | Darkens image (expands bright) |
| Gamma = 1 | Identity |
| `c` in log | `255 / log(1+max)` |
| Why 1+r | log(0) undefined |
| HE target | Flat (uniform) histogram |
| HE uses | CDF as the mapping function |
| CLAHE | Local equalization with contrast limit (clipLimit) to control noise |
| Dark image histogram | Concentrated at left (low values) |
| Low contrast histogram | Narrow, concentrated in a small range |
| Contrast stretching | Piecewise-linear, widens range to 0-255 |
| Thresholding | Piecewise special case (r1=r2) |
| Negative | `255 - r` |
| uint8 range | 0-255, overflows wrap (250+10 = 4) in NumPy; cv2.add saturates to 255 |
| Imread gray | `cv2.imread(path, 0)` or `cv2.IMREAD_GRAYSCALE` |
| OpenCV colour order | **BGR** (matplotlib wants RGB) |
| Equalize | `cv2.equalizeHist(gray)` (8-bit single channel only) |
| CLAHE | `cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8)).apply(img)` |
| Colour map | `cv2.applyColorMap(gray, cv2.COLORMAP_JET)` -> output is 3-channel BGR |
| Threshold | `cv2.threshold(img, T, 255, cv2.THRESH_BINARY)` returns `(T_used, image)` |
| Mask | `cv2.bitwise_and(img, img, mask=mask)` |
| Fusion | `cv2.addWeighted(img1, a, img2, b, 0)` |
| Video | `cv2.VideoCapture(file)`, `cap.read()` returns `(ok, frame)`, `cap.release()` |
| Webcam vs file | `VideoCapture(0)` = webcam, `VideoCapture('x.mp4')` = file |
| waitKey | `cv2.waitKey(30)` = wait 30 ms; `& 0xFF == ord('q')` to quit |
| Side by side | `np.hstack` / `cv2.hconcat` (same height, same channels) |
| Gray to 3-ch | `cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)` |
| Real-time ultrasound noise | White backscatter -> suppress with gamma > 1 |
| Underexposed X-ray | Use log or gamma < 1 |
| Washed-out (too bright) image | Use gamma > 1 |
| Why float before log | uint8 overflow and precision loss |

### Common trick questions
- "Which transform expands bright and compresses dark?" -> gamma > 1 (or inverse log).
- "Does HE always give a perfectly flat histogram?" -> No.
- "Does gamma change image size/shape?" -> No, only intensity.
- "Is histogram equalization a point operation?" -> Yes (global mapping via CDF; the standard HE is a point op).
- "Can addWeighted take images of different size?" -> No (error).
- "Is grayscale 1 channel?" -> Yes, shape (H, W). Colour is (H, W, 3).

---

## PART 3: EXAM QUICK-FIND (which file to open)

| If the question says... | Open this file |
|---|---|
| Histogram equalization, CDF, from scratch, CLAHE, plot histogram | `01_histogram_equalization_builtin_and_manual_and_CLAHE.py` |
| Log transform, dark image, expand dark | `02_log_transform.py` |
| Gamma, power-law, LUT | `03_gamma_power_law.py` |
| Contrast stretching, piecewise, r1 s1 r2 s2, min-max | `04_piecewise_contrast_stretching.py` |
| Negative, intensity slicing, bit-plane | `05_negative_and_intensity_slicing.py` |
| Heatmap, colour map, JET, false colour | `06_colormap_jet_heatmap.py` |
| Colour balance, colour cast, gray-world | `07_color_balance_gray_world_and_manual_shift.py` |
| Threshold, mask, Otsu, dense tissue, inRange | `08_thresholding_dense_tissue_mask.py` |
| Fusion, CT MRI, addWeighted, blend two images | `09_weighted_fusion_CT_MRI_addWeighted.py` |
| Video, VideoCapture, real-time, imshow, webcam | `10_video_pipeline_realtime_echo_imshow.py` |
| Save video, VideoWriter, Colab/Jupyter video | `11_video_save_and_colab_display.py` |

### Exam-day tips
1. Change only the file path and parameters (gamma, T, alpha).
2. `FileNotFound` / `NoneType has no attribute shape` -> wrong image path (imread returns None).
3. Colours look weird -> BGR vs RGB.
4. `addWeighted` error -> sizes or channels differ -> `cv2.resize` / `cvtColor(GRAY2BGR)`.
5. In Colab use `plt.imshow` (not `cv2.imshow`) or `from google.colab.patches import cv2_imshow`.
