# FILE 08: Thresholding / Colour Filtering (keep only densest tissue)
import cv2
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)
eq = cv2.equalizeHist(img)

# --- A) Fixed threshold ---
_, mask = cv2.threshold(eq, 200, 255, cv2.THRESH_BINARY)   # >200 -> 255, else 0
dense = cv2.bitwise_and(eq, eq, mask=mask)                 # keep only masked pixels

# --- B) Otsu (auto threshold) ---
t, otsu = cv2.threshold(eq, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# --- C) Range filter ---
band = cv2.inRange(eq, 150, 255)                           # 255 where 150<=pixel<=255

imgs = [eq, mask, dense, otsu]
titles = ['Equalized', 'Mask T=200', 'Dense only', f'Otsu T={int(t)}']
plt.figure(figsize=(16, 4))
for i in range(4):
    plt.subplot(1, 4, i + 1); plt.imshow(imgs[i], cmap='gray'); plt.title(titles[i]); plt.axis('off')
plt.show()
