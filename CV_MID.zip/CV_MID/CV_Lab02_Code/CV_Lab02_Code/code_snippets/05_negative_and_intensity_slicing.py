# FILE 05: Negative + Intensity-Level Slicing + Bit-Plane (extra point operations)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)

negative = 255 - img                              # s = (L-1) - r

# Intensity slicing: highlight range [100,200]
low, high = 100, 200
sliced = img.copy()
sliced[(img >= low) & (img <= high)] = 255        # range -> white, others kept

# Bit-plane: show bit 7 (most important bit)
bit7 = ((img >> 7) & 1) * 255                     # shift and mask the bit

imgs = [img, negative, sliced, bit7]
titles = ['Original', 'Negative', 'Slicing', 'Bit-plane 7']
plt.figure(figsize=(16, 4))
for i in range(4):
    plt.subplot(1, 4, i + 1); plt.imshow(imgs[i], cmap='gray'); plt.title(titles[i]); plt.axis('off')
plt.show()
