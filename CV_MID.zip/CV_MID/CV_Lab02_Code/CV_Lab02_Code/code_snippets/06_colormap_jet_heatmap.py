# FILE 06: False-Colour Heatmap (COLORMAP_JET) on equalized image
import cv2
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)
eq = cv2.equalizeHist(img)                        # step 1: equalize

heat = cv2.applyColorMap(eq, cv2.COLORMAP_JET)    # step 2: gray -> colour (BGR)
heat_rgb = cv2.cvtColor(heat, cv2.COLOR_BGR2RGB)  # OpenCV is BGR, matplotlib needs RGB

plt.imshow(heat_rgb); plt.title('JET heatmap'); plt.axis('off'); plt.show()
# Other maps: COLORMAP_HOT, COLORMAP_BONE, COLORMAP_VIRIDIS, COLORMAP_INFERNO
