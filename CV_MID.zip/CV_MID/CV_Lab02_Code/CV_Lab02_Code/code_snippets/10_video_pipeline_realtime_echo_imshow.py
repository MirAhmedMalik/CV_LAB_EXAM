# FILE 10: Real-time video pipeline (VideoCapture + all enhancements + side-by-side imshow)
# Run as normal .py on your PC (cv2.imshow does NOT work in Colab). Press 'q' to quit.
import cv2
import numpy as np

cap = cv2.VideoCapture('echo.mp4')                    # file, not webcam (0 = webcam)

while True:                                                # loop over frames
    ok, frame = cap.read()                                 # ok=False at end of video
    if not ok:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)         # 1) to gray
    eq = cv2.equalizeHist(gray)                            # 2) hist equalization
    heat = cv2.applyColorMap(eq, cv2.COLORMAP_JET)         # 3) heatmap

    b, g, r = cv2.split(heat.astype(np.float32))           # 4) colour balance (gray-world)
    avg = (b.mean() + g.mean() + r.mean()) / 3
    bal = cv2.merge([b * avg / (b.mean() + 1e-6),
                     g * avg / (g.mean() + 1e-6),
                     r * avg / (r.mean() + 1e-6)]).clip(0, 255)

    c = 255 / np.log(1 + float(bal.max()))                        # 5) log transform
    logd = c * np.log1p(bal)
    gam = 255 * np.power(logd / 255.0, 1.5)                # 6) gamma > 1 suppresses white noise
    out = np.uint8(gam)

    raw = cv2.resize(frame, (400, 400))                    # same size for hconcat
    out = cv2.resize(out, (400, 400))
    cv2.imshow('Raw (left) | Enhanced (right)', np.hstack([raw, out]))

    if cv2.waitKey(30) & 0xFF == ord('q'):                 # 30 ms/frame, q to quit
        break

cap.release()                                              # free the file
cv2.destroyAllWindows()                                    # close windows
