# FILE 07: Colour Balance (gray-world auto + manual channel shift)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)
heat = cv2.applyColorMap(cv2.equalizeHist(img), cv2.COLORMAP_JET)

# --- A) Gray-world: make mean of B, G, R equal ---
b, g, r = cv2.split(heat.astype(np.float32))      # split channels
avg = (b.mean() + g.mean() + r.mean()) / 3        # target mean
b = b * (avg / b.mean())                          # gain for each channel
g = g * (avg / g.mean())
r = r * (avg / r.mean())
balanced = cv2.merge([b, g, r]).clip(0, 255).astype(np.uint8)

# --- B) Manual shift: add/subtract per channel ---
shift = np.array([+15, 0, -15], dtype=np.int16)   # B, G, R offsets
shifted = np.clip(heat.astype(np.int16) + shift, 0, 255).astype(np.uint8)

imgs = [heat, balanced, shifted]
titles = ['Heatmap', 'Gray-world', 'Manual shift']
plt.figure(figsize=(14, 4))
for i in range(3):
    plt.subplot(1, 3, i + 1); plt.imshow(cv2.cvtColor(imgs[i], cv2.COLOR_BGR2RGB)); plt.title(titles[i]); plt.axis('off')
plt.show()
