# FILE 04: Piecewise-Linear Transformation (Contrast Stretching)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)

# Control points: (r1,s1) and (r2,s2)
r1, s1 = 70, 0        # pixels below r1 -> pushed to dark
r2, s2 = 180, 255     # pixels above r2 -> pushed to bright

# --- A) Short way: np.interp joins the points with straight lines ---
stretched = np.interp(img, [0, r1, r2, 255], [0, s1, s2, 255]).astype(np.uint8)

# --- B) Manual 3-segment way (shows the formula) ---
def piecewise(r):
    if r < r1:                                    # segment 1
        return (s1 / r1) * r
    elif r <= r2:                                 # segment 2
        return ((s2 - s1) / (r2 - r1)) * (r - r1) + s1
    else:                                         # segment 3
        return ((255 - s2) / (255 - r2)) * (r - r2) + s2
lut = np.array([piecewise(i) for i in range(256)], dtype=np.uint8)
stretched_manual = cv2.LUT(img, lut)              # apply to whole image

# --- C) Auto min-max stretch (no r1,r2 needed) ---
minmax = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)

imgs = [img, stretched, minmax]
titles = ['Original', 'Piecewise', 'Min-Max']
plt.figure(figsize=(14, 4))
for i in range(3):
    plt.subplot(1, 3, i + 1); plt.imshow(imgs[i], cmap='gray', vmin=0, vmax=255); plt.title(titles[i]); plt.axis('off')
plt.show()
