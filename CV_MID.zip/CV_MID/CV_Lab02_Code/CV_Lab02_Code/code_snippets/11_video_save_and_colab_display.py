# FILE 11: Process video and SAVE output (works in Colab / Jupyter, no imshow needed)
import cv2
import numpy as np
import matplotlib.pyplot as plt

cap = cv2.VideoCapture('echo.mp4')
fps = cap.get(cv2.CAP_PROP_FPS) or 25                      # frames per second
w, h = 400, 400
out_vid = cv2.VideoWriter('side_by_side.mp4',
                          cv2.VideoWriter_fourcc(*'mp4v'), fps, (w * 2, h))   # width = 2*w
count = 0
while True:
    ok, frame = cap.read()
    if not ok:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    eq = cv2.equalizeHist(gray)
    heat = cv2.applyColorMap(eq, cv2.COLORMAP_JET)
    c = 255 / np.log(1 + float(heat.max()))
    logd = c * np.log1p(heat.astype(np.float32))
    enh = np.uint8(255 * np.power(logd / 255.0, 1.5))
    both = np.hstack([cv2.resize(frame, (w, h)), cv2.resize(enh, (w, h))])
    out_vid.write(both)                                    # save frame
    if count == 30:                                        # show one frame in notebook
        plt.imshow(cv2.cvtColor(both, cv2.COLOR_BGR2RGB)); plt.axis('off'); plt.show()
    count += 1
cap.release(); out_vid.release()
