# FILE 01: Histogram Equalization (built-in + from scratch + CLAHE + histogram plot)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)      # 0 = load as grayscale

# --- A) Built-in ---
eq = cv2.equalizeHist(img)                       # spread intensities over 0-255

# --- B) From scratch (exam favourite) ---
hist = np.bincount(img.ravel(), minlength=256)   # count of each intensity
cdf = hist.cumsum()                              # cumulative sum
cdf_norm = (cdf - cdf.min()) / (cdf.max() - cdf.min()) * 255   # scale to 0-255
eq_manual = cdf_norm.astype(np.uint8)[img]       # map every pixel through the CDF

# --- C) CLAHE (local, limits noise) ---
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
eq_clahe = clahe.apply(img)

# --- Show images ---
titles = ['Original', 'Equalized', 'Manual', 'CLAHE']
imgs = [img, eq, eq_manual, eq_clahe]
plt.figure(figsize=(14, 7))
for i in range(4):
    plt.subplot(2, 4, i + 1); plt.imshow(imgs[i], cmap='gray'); plt.title(titles[i]); plt.axis('off')
    plt.subplot(2, 4, i + 5); plt.hist(imgs[i].ravel(), bins=256, range=(0, 256)); plt.title('Histogram')
plt.tight_layout(); plt.show()
