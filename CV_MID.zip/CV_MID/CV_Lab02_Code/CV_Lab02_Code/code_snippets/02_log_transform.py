# FILE 02: Logarithmic Transformation  s = c * log(1 + r)
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)

c = 255 / np.log(1 + float(np.max(img)))                 # scaling constant so max -> 255
log_img = c * np.log1p(img.astype(np.float32))    # log(1+r), float to avoid overflow
log_img = np.uint8(log_img)                       # back to 8-bit

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1); plt.imshow(img, cmap='gray'); plt.title('Original'); plt.axis('off')
plt.subplot(1, 2, 2); plt.imshow(log_img, cmap='gray'); plt.title('Log'); plt.axis('off')
plt.show()
