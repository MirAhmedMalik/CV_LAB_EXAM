# FILE 03: Power-Law (Gamma) Transformation  s = 255 * (r/255)^gamma
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('xray.png', 0)

def gamma_transform(image, gamma):
    norm = image / 255.0                          # scale to 0-1
    out = np.power(norm, gamma)                   # apply power
    return np.uint8(out * 255)                    # back to 0-255

# Faster way with a lookup table (LUT)
def gamma_lut(image, gamma):
    table = np.array([(i / 255.0) ** gamma * 255 for i in range(256)]).astype('uint8')
    return cv2.LUT(image, table)                  # map every pixel by table

g_dark = gamma_transform(img, 0.4)                # gamma < 1 -> brighter
g_same = gamma_transform(img, 1.0)                # gamma = 1 -> no change
g_bright = gamma_transform(img, 2.2)              # gamma > 1 -> darker

imgs = [img, g_dark, g_bright]
titles = ['Original', 'gamma=0.4 (brighter)', 'gamma=2.2 (darker)']
plt.figure(figsize=(14, 4))
for i in range(3):
    plt.subplot(1, 3, i + 1); plt.imshow(imgs[i], cmap='gray'); plt.title(titles[i]); plt.axis('off')
plt.show()
