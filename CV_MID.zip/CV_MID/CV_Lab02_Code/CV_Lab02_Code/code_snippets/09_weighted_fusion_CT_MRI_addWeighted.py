# FILE 09: CT + MRI Fusion with cv2.addWeighted + log + gamma + side-by-side
import cv2
import numpy as np
import matplotlib.pyplot as plt

ct = cv2.imread('ct.png', 0)
mri = cv2.imread('mri.png', 0)
mri = cv2.resize(mri, (ct.shape[1], ct.shape[0]))          # same size is a MUST

ct_eq = cv2.equalizeHist(ct)                               # equalize each separately
mri_eq = cv2.equalizeHist(mri)

ct_bgr = cv2.cvtColor(ct_eq, cv2.COLOR_GRAY2BGR)           # CT stays gray (edges)
mri_heat = cv2.applyColorMap(mri_eq, cv2.COLORMAP_JET)     # MRI becomes colour (tissue)

alpha, beta = 0.7, 0.3                                     # CT heavier, MRI lighter
fused = cv2.addWeighted(ct_bgr, alpha, mri_heat, beta, 0)  # alpha*A + beta*B + gamma

# log transform
c = 255 / np.log(1 + float(fused.max()))
fused_log = np.uint8(c * np.log1p(fused.astype(np.float32)))
# power-law transform
fused_final = np.uint8(255 * np.power(fused_log / 255.0, 0.8))

# side by side
rows = [cv2.cvtColor(ct_eq, cv2.COLOR_GRAY2RGB),
        cv2.cvtColor(mri_eq, cv2.COLOR_GRAY2RGB),
        cv2.cvtColor(fused_final, cv2.COLOR_BGR2RGB)]
titles = ['CT', 'MRI', 'Fused']
plt.figure(figsize=(14, 4))
for i in range(3):
    plt.subplot(1, 3, i + 1); plt.imshow(rows[i]); plt.title(titles[i]); plt.axis('off')
plt.show()
