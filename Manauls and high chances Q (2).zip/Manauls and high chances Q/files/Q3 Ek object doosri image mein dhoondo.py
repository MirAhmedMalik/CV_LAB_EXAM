# ===== Q3: SIFT matching + RANSAC outlier rejection + Homography =====
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Object image (img1) and scene image (img2), both read as grayscale
img1 = cv2.imread("image.jpg", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread("image2.jpg", cv2.IMREAD_GRAYSCALE)

# ---------- STEP 1: SIFT keypoints + 128-d descriptors ----------
# cv2.SIFT_create() -> SIFT detector object
sift = cv2.SIFT_create()
# detector.detectAndCompute(image, mask) -> (keypoints, descriptors)
kp1, des1 = sift.detectAndCompute(img1, None)
kp2, des2 = sift.detectAndCompute(img2, None)
print("Keypoints:", len(kp1), len(kp2), "| Descriptor shape:", des1.shape)

# ---------- STEP 2: Match descriptors (Euclidean distance) ----------
# cv2.BFMatcher(normType) -> brute-force matcher; NORM_L2 = Euclidean distance
bf = cv2.BFMatcher(cv2.NORM_L2)
# bf.knnMatch(queryDescriptors, trainDescriptors, k) -> k best matches for each descriptor
pairs = bf.knnMatch(des1, des2, k=2)

# Lowe's ratio test: keep a match only if best is clearly better than 2nd best
good = [m for m, n in pairs if m.distance < 0.75 * n.distance]
print("Good matches after ratio test:", len(good))

# ---------- STEP 3: RANSAC -> homography + remove outliers ----------
# Coordinates of matched points (shape N x 1 x 2, float32)
src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
# cv2.findHomography(srcPoints, dstPoints, method, ransacReprojThreshold)
#   -> (H 3x3 matrix, mask); mask[i]=1 means match i is an INLIER
H, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
print("Inliers kept by RANSAC:", int(mask.sum()), "of", len(good))
print("Homography H =\n", H)

# ---------- STEP 4: Draw matches (green = inliers only) ----------
# cv2.drawMatches(img1, kp1, img2, kp2, matches, outImg, matchesMask=..., flags=...)
match_img = cv2.drawMatches(img1, kp1, img2, kp2, good, None,
                            matchColor=(0, 255, 0),
                            matchesMask=mask.ravel().tolist(),
                            flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

# ---------- STEP 5: Outline the object inside the scene using H ----------
h, w = img1.shape
corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2)
# cv2.perspectiveTransform(src, M) -> applies 3x3 matrix M to the points
new_corners = cv2.perspectiveTransform(corners, H)
scene = cv2.cvtColor(img2, cv2.COLOR_GRAY2BGR)
# cv2.polylines(img, [points], isClosed, color, thickness)
cv2.polylines(scene, [np.int32(new_corners)], True, (0, 0, 255), 3)

# ---------- SHOW ----------
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1); plt.imshow(match_img); plt.title("RANSAC inlier matches"); plt.axis("off")
plt.subplot(1, 2, 2); plt.imshow(cv2.cvtColor(scene, cv2.COLOR_BGR2RGB)); plt.title("Object found (red outline)"); plt.axis("off")
plt.tight_layout()
plt.show()
