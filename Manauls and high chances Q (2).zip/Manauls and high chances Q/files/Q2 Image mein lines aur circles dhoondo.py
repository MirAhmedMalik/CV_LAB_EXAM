# ===== Q2: Hough Transform (lines + circles) =====
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread("image.jpg")                        # BGR color image
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)         # cv2.cvtColor(src, code)

# Hough works on EDGE pixels, so first: blur + Canny
# cv2.GaussianBlur(src, (kx, ky), sigma) -> blurred image
blur = cv2.GaussianBlur(gray, (5, 5), 1.4)
# cv2.Canny(image, lowThreshold, highThreshold) -> binary edge map
edges = cv2.Canny(blur, 50, 150)

# ---------- (a) Standard Hough lines: output is (rho, theta) ----------
# cv2.HoughLines(edges, rho, theta, threshold) -> array of [rho, theta]
#   rho = distance step (pixels), theta = angle step (radians),
#   threshold = minimum votes to accept a line
lines = cv2.HoughLines(edges, 1, np.pi / 180, 120)
out_lines = img.copy()
if lines is not None:
    for rho, theta in lines[:, 0]:
        a, b = np.cos(theta), np.sin(theta)
        x0, y0 = a * rho, b * rho                    # closest point of line to origin
        p1 = (int(x0 - 1000 * b), int(y0 + 1000 * a))    # point far in one direction
        p2 = (int(x0 + 1000 * b), int(y0 - 1000 * a))    # point far in other direction
        # cv2.line(img, pt1, pt2, color(BGR), thickness)
        cv2.line(out_lines, p1, p2, (0, 0, 255), 2)

# ---------- (b) Probabilistic Hough: gives line SEGMENTS (x1,y1,x2,y2) ----------
# cv2.HoughLinesP(edges, rho, theta, threshold, minLineLength, maxLineGap)
segs = cv2.HoughLinesP(edges, 1, np.pi / 180, 80, minLineLength=60, maxLineGap=10)
out_segs = img.copy()
if segs is not None:
    for x1, y1, x2, y2 in segs[:, 0]:
        cv2.line(out_segs, (x1, y1), (x2, y2), (0, 255, 0), 2)

# ---------- (c) Hough circles: output is (a, b, r) = center x, center y, radius ----------
# cv2.medianBlur(src, ksize) -> removes noise (circle detector likes smooth image)
smooth = cv2.medianBlur(gray, 5)
# cv2.HoughCircles(image, method, dp, minDist, param1, param2, minRadius, maxRadius)
#   dp = accumulator resolution, minDist = min distance between centers,
#   param1 = Canny high threshold, param2 = votes needed (lower = more circles)
circles = cv2.HoughCircles(smooth, cv2.HOUGH_GRADIENT, dp=1, minDist=50,
                           param1=100, param2=30, minRadius=20, maxRadius=100)
out_circles = img.copy()
if circles is not None:
    for a, b, r in np.round(circles[0]).astype(int):
        # cv2.circle(img, center, radius, color, thickness)
        cv2.circle(out_circles, (a, b), r, (0, 255, 0), 2)    # circle outline
        cv2.circle(out_circles, (a, b), 3, (0, 0, 255), -1)   # center dot

# ---------- (d) Hough lines FROM SCRATCH (voting in rho-theta space) ----------
ys, xs = np.nonzero(edges)                           # coordinates of all edge pixels
thetas = np.deg2rad(np.arange(0, 180))               # angles 0..179 degrees
diag = int(np.hypot(*edges.shape))                   # max possible |rho|
acc = np.zeros((2 * diag, len(thetas)), np.int32)    # accumulator (rho x theta)
for x, y in zip(xs, ys):                             # every edge pixel votes
    rhos = np.round(x * np.cos(thetas) + y * np.sin(thetas)).astype(int) + diag
    acc[rhos, np.arange(len(thetas))] += 1           # +1 vote for each (rho, theta)
r_idx, t_idx = np.unravel_index(acc.argmax(), acc.shape)   # peak = strongest line
print("Strongest line: rho =", r_idx - diag, " theta =", np.rad2deg(thetas[t_idx]), "deg")

# ---------- SHOW ----------
rgb = lambda im: cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
items = [("Canny edges", edges), ("HoughLines", rgb(out_lines)),
         ("HoughLinesP", rgb(out_segs)), ("HoughCircles", rgb(out_circles))]
plt.figure(figsize=(14, 7))
for i, (t, im) in enumerate(items):
    plt.subplot(2, 2, i + 1)
    plt.imshow(im, cmap="gray" if im.ndim == 2 else None)
    plt.title(t)
    plt.axis("off")
plt.tight_layout()
plt.show()
