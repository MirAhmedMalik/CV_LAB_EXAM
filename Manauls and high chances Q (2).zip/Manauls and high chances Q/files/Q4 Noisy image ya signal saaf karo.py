# ===== Q4: Wavelet Transform (DWT, reconstruction, denoising) =====
# Install if needed:  pip install PyWavelets
import cv2
import numpy as np
import pywt
import matplotlib.pyplot as plt

gray = cv2.imread("image.jpg", cv2.IMREAD_GRAYSCALE).astype(np.float32)

# ---------- (a) 1-level 2D DWT ----------
# pywt.dwt2(data, wavelet) -> (LL, (LH, HL, HH))
#   LL = approximation (low freq), LH = horizontal edges,
#   HL = vertical edges, HH = diagonal details
LL, (LH, HL, HH) = pywt.dwt2(gray, "haar")

# ---------- (b) Inverse DWT (perfect reconstruction) ----------
# pywt.idwt2(coeffs, wavelet) -> rebuilt image
rebuilt = pywt.idwt2((LL, (LH, HL, HH)), "haar")
print("Reconstruction error:", np.abs(gray - rebuilt).max())    # ~0

# ---------- (c) Multi-level DWT (2 levels) ----------
# pywt.wavedec2(data, wavelet, level) -> [cA2, (cH2,cV2,cD2), (cH1,cV1,cD1)]
coeffs = pywt.wavedec2(gray, "db2", level=2)

# ---------- (d) Denoising: add noise -> threshold details -> reconstruct ----------
# np.random.normal(mean, std, size) -> random Gaussian noise
noisy = gray + np.random.normal(0, 25, gray.shape)
c = pywt.wavedec2(noisy, "db2", level=2)
T = 40                                               # threshold (bigger = more smoothing)
new_c = [c[0]]                                       # keep approximation (LL) as it is
for detail in c[1:]:                                 # for each level of details
    # pywt.threshold(data, value, mode) -> 'soft' shrinks small coefficients to 0
    new_c.append(tuple(pywt.threshold(d, T, mode="soft") for d in detail))
# pywt.waverec2(coeffs, wavelet) -> rebuilt image from coefficients
clean = pywt.waverec2(new_c, "db2")[:gray.shape[0], :gray.shape[1]]

# PSNR = 10*log10(255^2 / MSE)  (higher = closer to original)
def psnr(a, b):
    mse = np.mean((a - b) ** 2)
    return 10 * np.log10(255 ** 2 / mse)
print("PSNR noisy :", round(psnr(gray, noisy), 2))
print("PSNR clean :", round(psnr(gray, clean), 2))

# ---------- (e) 1D signal denoising (like the audio example in the manual) ----------
t = np.linspace(0, 1, 1024)
signal = np.sin(2 * np.pi * 5 * t)                   # clean signal
noisy1 = signal + 0.4 * np.random.randn(len(t))      # noisy signal
# pywt.wavedec(data, wavelet, level) -> [cA, cD_n, ..., cD_1]
c1 = pywt.wavedec(noisy1, "db4", level=4)
c1[1:] = [pywt.threshold(d, 0.5, mode="soft") for d in c1[1:]]   # threshold details only
clean1 = pywt.waverec(c1, "db4")[:len(t)]            # pywt.waverec(coeffs, wavelet)

# ---------- SHOW ----------
plt.figure(figsize=(14, 8))
titles = ["LL (approx)", "LH (horizontal)", "HL (vertical)", "HH (diagonal)"]
for i, (title, band) in enumerate(zip(titles, [LL, LH, HL, HH])):
    plt.subplot(3, 4, i + 1); plt.imshow(band, cmap="gray"); plt.title(title); plt.axis("off")
plt.subplot(3, 4, 5); plt.imshow(gray, cmap="gray"); plt.title("Original"); plt.axis("off")
plt.subplot(3, 4, 6); plt.imshow(noisy, cmap="gray"); plt.title("Noisy"); plt.axis("off")
plt.subplot(3, 4, 7); plt.imshow(clean, cmap="gray"); plt.title("Denoised"); plt.axis("off")
plt.subplot(3, 1, 3)
plt.plot(noisy1, alpha=0.4, label="Noisy"); plt.plot(clean1, label="Cleaned"); plt.legend()
plt.tight_layout()
plt.show()
