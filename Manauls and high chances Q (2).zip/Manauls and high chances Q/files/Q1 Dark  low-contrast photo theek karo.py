# ===== Q1: Log, Gamma, Piecewise (contrast stretching), Histogram + Equalization =====
import cv2
import numpy as np
import matplotlib.pyplot as plt

# cv2.imread(path, flag) -> image array; IMREAD_GRAYSCALE = 1 channel, values 0-255
gray = cv2.imread("image.jpg", cv2.IMREAD_GRAYSCALE)

# ---------- 1) LOG transform:  s = c * log(1 + r) ----------
# np.log(x) -> natural log of every element
c = 255 / np.log(1 + float(gray.max()))             # float() avoids uint8 overflow (255+1)
log_img = c * np.log(1 + gray.astype(np.float32))    # 1+r because log(0) is undefined
log_img = np.uint8(log_img)                          # back to 8-bit

# ---------- 2) GAMMA transform:  s = 255 * (r/255)^gamma ----------
# np.power(x, p) -> x ** p for every element
gamma = 0.5                                          # <1 brighter, >1 darker
norm = gray / 255.0                                  # scale to 0-1
gamma_img = np.uint8(255 * np.power(norm, gamma))    # apply power, scale back

# ---------- 3) PIECEWISE-LINEAR (contrast stretching) ----------
# Points: (0,0) -> (r1,s1) -> (r2,s2) -> (255,255)
r1, s1 = 70, 20
r2, s2 = 180, 235
# np.interp(x, xp, fp) -> for each x, finds value on the line joining points (xp, fp)
lut = np.interp(np.arange(256), [0, r1, r2, 255], [0, s1, s2, 255])
# cv2.LUT(src, lut) -> replaces every pixel value v with lut[v]
piecewise = cv2.LUT(gray, lut.astype(np.uint8))

# ---------- 4) HISTOGRAM EQUALIZATION ----------
# (a) Built-in: cv2.equalizeHist(src) -> equalized image (src must be 8-bit 1-channel)
eq_cv = cv2.equalizeHist(gray)

# (b) Manual: s = (L-1) * CDF(r)
# np.bincount(x, minlength) -> counts how many times each value 0..255 appears
hist = np.bincount(gray.ravel(), minlength=256)
cdf = hist.cumsum()                                  # running sum of histogram
s_map = np.round(255 * cdf / cdf[-1]).astype(np.uint8)   # new level for every old level
eq_manual = s_map[gray]                              # replace each pixel using the map

# ---------- 5) SHOW images + their histograms ----------
images = [("Original", gray), ("Log", log_img), ("Gamma 0.5", gamma_img),
          ("Piecewise", piecewise), ("Equalized", eq_cv)]

plt.figure(figsize=(16, 6))
for i, (title, im) in enumerate(images):
    # plt.subplot(rows, cols, index)
    plt.subplot(2, 5, i + 1)
    plt.imshow(im, cmap="gray", vmin=0, vmax=255)
    plt.title(title)
    plt.axis("off")

    # cv2.calcHist([img], [channel], mask, [bins], [range]) -> histogram (256,1)
    h = cv2.calcHist([im], [0], None, [256], [0, 256])
    plt.subplot(2, 5, i + 6)
    plt.plot(h)
    plt.title("Histogram")
plt.tight_layout()
plt.show()
