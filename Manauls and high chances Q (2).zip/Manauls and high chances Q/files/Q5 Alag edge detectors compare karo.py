# ===== Q5: Edge detectors NOT coded in manual: Prewitt, Scharr, Laplacian, LoG zero-crossing =====
import cv2
import numpy as np
import matplotlib.pyplot as plt

gray = cv2.imread("image.jpg", cv2.IMREAD_GRAYSCALE)

# Helper: turn float gradient values into a displayable 8-bit image
# cv2.convertScaleAbs(src) -> |src| clipped to 0-255, uint8
def show(x):
    return cv2.convertScaleAbs(x)

# ---------- (a) PREWITT (kernels made by hand) ----------
prewitt_x = np.array([[-1, 0, 1],
                      [-1, 0, 1],
                      [-1, 0, 1]], dtype=np.float32)      # detects vertical edges
prewitt_y = np.array([[-1, -1, -1],
                      [ 0,  0,  0],
                      [ 1,  1,  1]], dtype=np.float32)    # detects horizontal edges
# cv2.filter2D(src, ddepth, kernel) -> convolution; CV_64F keeps negative values
px = cv2.filter2D(gray, cv2.CV_64F, prewitt_x)
py = cv2.filter2D(gray, cv2.CV_64F, prewitt_y)
# cv2.magnitude(x, y) -> sqrt(x^2 + y^2)
prewitt = show(cv2.magnitude(px, py))

# ---------- (b) SOBEL (for comparison) ----------
# cv2.Sobel(src, ddepth, dx, dy, ksize=3)
sx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
sobel = show(cv2.magnitude(sx, sy))

# ---------- (c) SCHARR (more accurate 3x3 gradient) ----------
# cv2.Scharr(src, ddepth, dx, dy)
cx = cv2.Scharr(gray, cv2.CV_64F, 1, 0)
cy = cv2.Scharr(gray, cv2.CV_64F, 0, 1)
scharr = show(cv2.magnitude(cx, cy))

# ---------- (d) LAPLACIAN alone (2nd derivative, very noise sensitive) ----------
# cv2.Laplacian(src, ddepth) -> second derivative of the image
lap = show(cv2.Laplacian(gray, cv2.CV_64F))

# ---------- (e) LoG = Gaussian blur -> Laplacian -> ZERO-CROSSINGS ----------
# cv2.GaussianBlur(src, (kx, ky), sigma)
blur = cv2.GaussianBlur(gray, (5, 5), 1.4)
log = cv2.Laplacian(blur, cv2.CV_64F)

# Edge = place where LoG changes sign (+ to - or - to +) with a big enough jump
sign = np.sign(log)
thr = 0.2 * np.abs(log).max()                        # ignore tiny weak crossings
zero_cross = np.zeros(gray.shape, np.uint8)
# compare each pixel with its RIGHT neighbour
h_cross = (sign[:, :-1] * sign[:, 1:] < 0) & (np.abs(log[:, :-1] - log[:, 1:]) > thr)
# compare each pixel with its BOTTOM neighbour
v_cross = (sign[:-1, :] * sign[1:, :] < 0) & (np.abs(log[:-1, :] - log[1:, :]) > thr)
zero_cross[:, :-1][h_cross] = 255
zero_cross[:-1, :][v_cross] = 255

# ---------- (f) CANNY (best one) ----------
# cv2.Canny(image, lowThreshold, highThreshold)
canny = cv2.Canny(blur, 50, 150)

# ---------- SHOW ----------
items = [("Original", gray), ("Prewitt", prewitt), ("Sobel", sobel), ("Scharr", scharr),
         ("Laplacian", lap), ("LoG zero-crossing", zero_cross), ("Canny", canny)]
plt.figure(figsize=(15, 8))
for i, (title, im) in enumerate(items):
    plt.subplot(2, 4, i + 1)
    plt.imshow(im, cmap="gray")
    plt.title(title)
    plt.axis("off")
plt.tight_layout()
plt.show()
