# ===== BIG Q2: Frere Hall recognition app (tourist photo -> verify landmark) =====
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.feature import local_binary_pattern, hog

# ---------------------------------------------------------------
# STEP 0: Reference image of the landmark
# ---------------------------------------------------------------
# cv2.imread(path) -> BGR image
ref = cv2.imread("frerehall.jpg")
ref_gray = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY)         # cv2.cvtColor(src, code)
h, w = ref_gray.shape

# ---------------------------------------------------------------
# STEP 1: GEOMETRIC transformations as 3x3 homogeneous matrices
#         (simulate tourists taking photos from different positions)
# ---------------------------------------------------------------
# cv2.getRotationMatrix2D(center, angle, scale) -> 2x3 matrix (rotation+scale about centre)
# Convert 2x3 -> 3x3 so matrices can be multiplied (composition)
def to3x3(M):
    return np.vstack([M, [0, 0, 1]])

def translation(tx, ty):
    return np.array([[1, 0, tx], [0, 1, ty], [0, 0, 1]], dtype=np.float64)

centre = (w // 2, h // 2)
true_angle = 25
rigid = translation(40, 20) @ to3x3(cv2.getRotationMatrix2D(centre, true_angle, 1.0))      # scale = 1
similar = translation(60, 30) @ to3x3(cv2.getRotationMatrix2D(centre, 12, 0.7))            # scale 0.7
shear = np.array([[1, 0.25, 0], [0, 1, 0], [0, 0, 1]], dtype=np.float64)                   # x-shear
# cv2.getPerspectiveTransform(src4, dst4) -> 3x3 homography from 4 point pairs
src4 = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
dst4 = np.float32([[60, 40], [w - 40, 0], [w - 20, h - 30], [20, h - 10]])
persp = cv2.getPerspectiveTransform(src4, dst4)

# Evening photo: dark (gamma > 1) + blurry phone camera (Gaussian kernel by convolution)
# cv2.getGaussianKernel(ksize, sigma) -> column kernel ; outer product -> 2D kernel
g1 = cv2.getGaussianKernel(7, 2.0)
kernel = g1 @ g1.T
dark = np.uint8(255 * np.power(ref_gray / 255.0, 1.8))
# cv2.filter2D(src, ddepth, kernel) -> convolution (ddepth -1 = same type as src)
dark_blur = cv2.filter2D(dark, -1, kernel)

# cv2.warpPerspective(src, M, (width, height)) -> image transformed by 3x3 matrix
queries = {
    "rigid 25deg":  cv2.warpPerspective(ref_gray, rigid,   (w + 80, h + 80)),
    "similar 0.7x": cv2.warpPerspective(ref_gray, similar, (w + 80, h + 80)),
    "x-shear":      cv2.warpPerspective(ref_gray, shear,   (w + 200, h)),
    "perspective":  cv2.warpPerspective(ref_gray, persp,   (w, h)),
    "dark+blur":    dark_blur,
}
# Restore the dark+blur one with histogram equalization before matching
# cv2.equalizeHist(src) -> contrast-enhanced image (8-bit gray only)
queries["dark+blur"] = cv2.equalizeHist(queries["dark+blur"])

# ---------------------------------------------------------------
# STEP 2: SEGMENT the building from the reference (K-Means + morphology)
# ---------------------------------------------------------------
pixels = ref.reshape(-1, 3).astype(np.float32)           # N x 3 colour vectors
crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 50, 0.5)
# cv2.kmeans(data, K, bestLabels, criteria, attempts, flags) -> (compactness, labels, centers)
_, labels, centers = cv2.kmeans(pixels, 3, None, crit, 5, cv2.KMEANS_PP_CENTERS)
bg_cluster = np.argmax(centers.sum(axis=1))              # brightest cluster = white background
mask = (labels.reshape(h, w) != bg_cluster).astype(np.uint8) * 255

# Clean the mask: close small holes, then remove small specks
kern = np.ones((7, 7), np.uint8)
# cv2.morphologyEx(src, op, kernel) -> MORPH_CLOSE fills holes, MORPH_OPEN removes specks
mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kern, iterations=2)
mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kern)
# Keep only the largest blob (the building)
# cv2.connectedComponentsWithStats(binary) -> (n, labels, stats, centroids)
n, cc, stats, _ = cv2.connectedComponentsWithStats(mask)
biggest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
mask = np.uint8(cc == biggest) * 255
x, y, bw, bh = [int(v) for v in stats[biggest, :4]]                        # bounding box of the building
print("STEP 2 | building covers", round(100 * mask.mean() / 255, 1), "% of image; box =", (x, y, bw, bh))

# ---------------------------------------------------------------
# STEP 3: SIFT + ratio test + RANSAC for every query photo
# ---------------------------------------------------------------
sift = cv2.SIFT_create()                                 # cv2.SIFT_create()
# detector.detectAndCompute(image, mask) -> (keypoints, descriptors)
kp_r, des_r = sift.detectAndCompute(ref_gray, mask)      # only keypoints ON the building
bf = cv2.BFMatcher(cv2.NORM_L2)                          # Euclidean distance matcher

# Texture/edge descriptors used for verification (computed on the building crop)
def describe(img_gray, bbox):
    x, y, bw, bh = bbox
    crop = cv2.resize(img_gray[y:y + bh, x:x + bw], (128, 128))
    # local_binary_pattern(image, P, R, method) -> LBP code image
    lbp = local_binary_pattern(crop, 8, 1, method="uniform")
    # np.histogram(a, bins, range) -> (counts, edges)
    lbp_hist, _ = np.histogram(lbp, bins=10, range=(0, 10))
    lbp_hist = (lbp_hist / lbp_hist.sum()).astype(np.float32)
    # hog(image, pixels_per_cell, cells_per_block) -> feature vector
    hog_vec = hog(crop, pixels_per_cell=(16, 16), cells_per_block=(2, 2))
    # cv2.Canny(image, low, high) -> edge map ; density = edge pixels / total pixels
    edge_density = (cv2.Canny(crop, 80, 160) > 0).mean()
    return lbp_hist, hog_vec, edge_density

ref_lbp, ref_hog, ref_ed = describe(ref_gray, (x, y, bw, bh))

print("\nSTEP 3 | transform      kp   good  inliers  angle(est/true)  LBPcorr  HOGcos  edgeDens(ref/q)")
results = {}
for name, q in queries.items():
    kp_q, des_q = sift.detectAndCompute(q, None)
    pairs = bf.knnMatch(des_r, des_q, k=2)
    good = [m for m, n_ in pairs if m.distance < 0.75 * n_.distance]   # Lowe ratio test
    if len(good) < 4:
        print("   ", name.ljust(14), "not enough matches")
        continue
    src_pts = np.float32([kp_r[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp_q[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    # cv2.findHomography(src, dst, method, reprojThresh) -> (H, inlier_mask)
    H, inl = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 4.0)
    n_in = int(inl.sum())

    # Rotation angle recovered from H (valid only for rigid / similarity)
    est_angle = np.degrees(np.arctan2(-H[1, 0], H[0, 0]))

    # Undo the transform: warp query back into the reference frame using inverse(H)
    # np.linalg.inv(A) -> matrix inverse
    aligned = cv2.warpPerspective(q, np.linalg.inv(H), (w, h))
    lbp_q, hog_q, ed_q = describe(aligned, (x, y, bw, bh))
    # cv2.compareHist(h1, h2, method) -> similarity ; HISTCMP_CORREL = correlation (1 = same)
    lbp_corr = cv2.compareHist(ref_lbp, lbp_q, cv2.HISTCMP_CORREL)
    hog_cos = float(np.dot(ref_hog, hog_q) / (np.linalg.norm(ref_hog) * np.linalg.norm(hog_q)))
    print("   ", name.ljust(14), str(len(kp_q)).rjust(4), str(len(good)).rjust(5), str(n_in).rjust(7),
          ("%6.1f/%d" % (est_angle, true_angle) if name == "rigid 25deg" else "      -    ").rjust(15),
          "%7.2f" % lbp_corr, "%7.2f" % hog_cos, " %.3f/%.3f" % (ref_ed, ed_q))
    results[name] = (kp_q, good, inl, aligned, H)

# ---------------------------------------------------------------
# SHOW
# ---------------------------------------------------------------
seg_vis = ref.copy()
seg_vis[mask == 0] = (seg_vis[mask == 0] * 0.2).astype(np.uint8)       # darken background
items = [("Reference", cv2.cvtColor(ref, cv2.COLOR_BGR2RGB)), ("Building segment", cv2.cvtColor(seg_vis, cv2.COLOR_BGR2RGB))]
for name, (kp_q, good, inl, aligned, H) in results.items():
    items.append((name + " -> aligned back", aligned))
plt.figure(figsize=(16, 8))
for i, (t, im) in enumerate(items[:8]):
    plt.subplot(2, 4, i + 1)
    plt.imshow(im, cmap="gray" if im.ndim == 2 else None)
    plt.title(t)
    plt.axis("off")
plt.tight_layout()
plt.show()
