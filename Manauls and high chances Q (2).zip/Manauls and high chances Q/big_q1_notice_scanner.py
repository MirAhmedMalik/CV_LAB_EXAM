# ===== BIG Q1: Notice-board scanner (dark photo -> clean flat A4 scan) =====
import cv2
import numpy as np
import pywt
import matplotlib.pyplot as plt

# ---------------------------------------------------------------
# STEP 0: Read photo (BGR) and convert to gray
# ---------------------------------------------------------------
# cv2.imread(path) -> BGR image ; cv2.cvtColor(src, code) -> converted image
photo = cv2.imread("notice.jpg")
gray = cv2.cvtColor(photo, cv2.COLOR_BGR2GRAY)
print("STEP 0 | mean =", round(gray.mean(), 1), " std =", round(gray.std(), 1))

# ---------------------------------------------------------------
# STEP 1: PHOTOMETRIC restoration (photo is too dark)
# ---------------------------------------------------------------
# (a) LOG:  s = c*log(1+r)       np.log(x) -> natural log
c = 255 / np.log(1 + float(gray.max()))
log_img = np.uint8(c * np.log(1 + gray.astype(np.float32)))

# (b) GAMMA: choose gamma automatically so the MEAN brightness becomes 0.5
#     s = r^gamma  ->  mean^gamma = 0.5  ->  gamma = log(0.5)/log(mean)
mean01 = gray.mean() / 255.0
gamma = np.log(0.5) / np.log(mean01)
# np.power(x, p) -> x ** p
gamma_img = np.uint8(255 * np.power(gray / 255.0, gamma))
print("STEP 1 | auto gamma =", round(gamma, 2), "(<1 means brighten)")

# (c) PIECEWISE (contrast stretching) using 2nd and 98th percentile as r1, r2
# np.percentile(a, q) -> value below which q% of data lies
r1, r2 = np.percentile(gamma_img, 2), np.percentile(gamma_img, 98)
# np.interp(x, xp, fp) -> piecewise-linear mapping through points (xp, fp)
lut = np.interp(np.arange(256), [0, r1, r2, 255], [0, 0, 255, 255])
# cv2.LUT(src, lut) -> every pixel value v becomes lut[v]
stretched = cv2.LUT(gamma_img, lut.astype(np.uint8))

# (d) HISTOGRAM EQUALIZATION (for comparison)   cv2.equalizeHist(src)
equalized = cv2.equalizeHist(gray)

# Compare by contrast (std). Higher std = more contrast
for name, im in [("original", gray), ("log", log_img), ("gamma", gamma_img),
                 ("gamma+stretch", stretched), ("equalized", equalized)]:
    print("   ", name.ljust(14), "std =", round(im.std(), 1))
enhanced = stretched          # we continue with gamma + stretch

# ---------------------------------------------------------------
# STEP 2: WAVELET DENOISING (noise level estimated from the image itself)
# ---------------------------------------------------------------
# pywt.wavedec2(data, wavelet, level) -> [cA2, (cH2,cV2,cD2), (cH1,cV1,cD1)]
coeffs = pywt.wavedec2(enhanced.astype(np.float32), "db2", level=2)
HH = coeffs[-1][2]                                  # finest diagonal details = mostly noise
sigma = np.median(np.abs(HH)) / 0.6745              # robust noise std (MAD estimator)
T = sigma * np.sqrt(2 * np.log(enhanced.size))      # universal threshold
print("STEP 2 | noise sigma =", round(sigma, 2), " threshold =", round(T, 2))

new_coeffs = [coeffs[0]]                            # keep approximation (LL) untouched
for detail in coeffs[1:]:
    # pywt.threshold(data, value, mode) -> 'soft' shrinks small coefficients to 0
    new_coeffs.append(tuple(pywt.threshold(d, T, mode="soft") for d in detail))
# pywt.waverec2(coeffs, wavelet) -> rebuilt image
den = pywt.waverec2(new_coeffs, "db2")[:gray.shape[0], :gray.shape[1]]
den = np.uint8(np.clip(den, 0, 255))

# ---------------------------------------------------------------
# STEP 3: EDGES (Canny with automatic thresholds)
# ---------------------------------------------------------------
# cv2.GaussianBlur(src, (kx, ky), sigma) -> smoothed image
blur = cv2.GaussianBlur(den, (5, 5), 1.4)
med = np.median(blur)
low, high = int(max(0, 0.66 * med)), int(min(255, 1.33 * med))
# cv2.Canny(image, lowThreshold, highThreshold) -> binary edge map
edges = cv2.Canny(blur, low, high)

# ---------------------------------------------------------------
# STEP 4: HOUGH -> find the 4 border lines of the page
# ---------------------------------------------------------------
h, w = gray.shape
# cv2.HoughLines(edges, rho, theta, threshold) -> lines as [rho, theta]
lines = cv2.HoughLines(edges, 1, np.pi / 180, 150)
lines = lines[:, 0]                                 # shape (N, 2)
print("STEP 4 | Hough lines found =", len(lines))

xc, yc = w / 2, h / 2                               # image centre
horiz, vert = [], []                                # (position, rho, theta)
for rho, theta in lines:
    a, b = np.cos(theta), np.sin(theta)
    if abs(b) > 0.7:                                # near-horizontal line
        y_at_centre = (rho - xc * a) / b            # where it crosses x = centre
        horiz.append((y_at_centre, rho, theta))
    elif abs(a) > 0.7:                              # near-vertical line
        x_at_centre = (rho - yc * b) / a            # where it crosses y = centre
        vert.append((x_at_centre, rho, theta))

# outermost lines = page borders (top/bottom smallest/largest y, left/right smallest/largest x)
top, bottom = min(horiz), max(horiz)
left, right = min(vert), max(vert)

# Homogeneous line  a*x + b*y - rho = 0  ->  l = [cos, sin, -rho]
def hline(item):
    _, rho, theta = item
    return np.array([np.cos(theta), np.sin(theta), -rho])

# Intersection of two lines = cross product (homogeneous coordinates)
# np.cross(a, b) -> vector perpendicular to a and b
def intersect(l1, l2):
    p = np.cross(l1, l2)
    return p[:2] / p[2]                             # divide by w to get (x, y)

TL = intersect(hline(top), hline(left))
TR = intersect(hline(top), hline(right))
BR = intersect(hline(bottom), hline(right))
BL = intersect(hline(bottom), hline(left))
corners = np.float32([TL, TR, BR, BL])
print("STEP 4 | corners (TL,TR,BR,BL) =\n", corners.round(1))

# ---------------------------------------------------------------
# STEP 5: PERSPECTIVE correction (homography) -> flat page
# ---------------------------------------------------------------
W = int(max(np.linalg.norm(TR - TL), np.linalg.norm(BR - BL)))   # output width
H = int(max(np.linalg.norm(BL - TL), np.linalg.norm(BR - TR)))   # output height
dst = np.float32([[0, 0], [W - 1, 0], [W - 1, H - 1], [0, H - 1]])
# cv2.getPerspectiveTransform(src4, dst4) -> 3x3 matrix
M = cv2.getPerspectiveTransform(corners, dst)
# cv2.warpPerspective(src, M, (width, height)) -> warped image
flat = cv2.warpPerspective(den, M, (W, H))

# ---------------------------------------------------------------
# STEP 6: SEGMENT text from paper (Otsu vs Adaptive thresholding)
# ---------------------------------------------------------------
# cv2.threshold(src, thresh, maxval, type) -> (used_threshold, binary)
t_otsu, otsu = cv2.threshold(flat, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
# cv2.adaptiveThreshold(src, maxval, method, type, blockSize, C)
adap = cv2.adaptiveThreshold(flat, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                             cv2.THRESH_BINARY_INV, 31, 15)
print("STEP 6 | Otsu threshold =", t_otsu)

# Count text blobs using connected components (ignore tiny noise < 20 px)
# cv2.connectedComponentsWithStats(binary) -> (n, labels, stats, centroids)
for name, b in [("Otsu", otsu), ("Adaptive", adap)]:
    n, _, stats, _ = cv2.connectedComponentsWithStats(b)
    blobs = int(np.sum(stats[1:, cv2.CC_STAT_AREA] >= 20))
    print("   ", name.ljust(8), "text blobs =", blobs)

# ---------------------------------------------------------------
# SHOW
# ---------------------------------------------------------------
vis = cv2.cvtColor(den, cv2.COLOR_GRAY2BGR)
for p in corners:
    cv2.circle(vis, (int(p[0]), int(p[1])), 12, (0, 0, 255), -1)
items = [("Original (dark)", gray), ("After gamma+stretch", enhanced), ("Wavelet denoised", den),
         ("Canny edges", edges), ("Detected corners", cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)),
         ("Flat page", flat), ("Otsu", otsu), ("Adaptive", adap)]
plt.figure(figsize=(16, 8))
for i, (t, im) in enumerate(items):
    plt.subplot(2, 4, i + 1)
    plt.imshow(im, cmap="gray" if im.ndim == 2 else None)
    plt.title(t)
    plt.axis("off")
plt.tight_layout()
plt.show()
